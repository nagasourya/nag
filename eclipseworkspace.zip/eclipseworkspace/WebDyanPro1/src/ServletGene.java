

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ServletGene")
public class ServletGene extends GenericServlet implements Servlet {
	private static final long serialVersionUID = 1L;
       
   
    public ServletGene() {
        super();
       
    }

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<html>");
		out.println("<head>");
		out.println("<title> Welcome Page</title>");
		out.println("</head>");
		out.println("<body>");

		out.println("<h1>This is the page invoked when i send a request</h1> ");
		out.print(new Date().getDate());
		out.println("</body>");
		out.println("</html>");
		
		
	
	}

}
