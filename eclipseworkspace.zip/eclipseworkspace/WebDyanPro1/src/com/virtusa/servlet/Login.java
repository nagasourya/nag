package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends GenericServlet {
	

	/**
	 * @see Servlet#service(ServletRequest request, ServletResponse response)
	 */
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String u=request.getParameter("username");
		String p=request.getParameter("pwd");
         if(u.equals("sravani")&& p.equals("sravani"))
         {
        	 out.println("<html>");
     		out.println("<head>");
     		out.println("<title> Welcome Page</title>");
     		out.println("</head>");
     		out.println("<body>");
     		out.println("username"+u);
     		out.println("username"+p);
     		out.println("</body>");
     		out.println("</html>");
         }
         else
         {out.println("<html>");
 		out.println("<head>");
 		out.println("<title> Welcome Page</title>");
 		out.println("</head>");
 		out.println("<body>");
 		out.println("enter the correct credentials");
 		out.println("<meta http-EQUIV=\"refresh\" content=\"0; URL=\'Login.html'\" />");
        
 		out.println("</body>");
 		out.println("</html>");
        	 
         }
	}

}
