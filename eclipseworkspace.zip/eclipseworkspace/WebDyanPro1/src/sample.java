

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class sample
 */
@WebServlet("/sample")
public class sample extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public sample() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			Connection conn = OracleConnection.getConnection();
			out.println("Connection  "+conn);
		Statement stmt=conn.createStatement();
		int i=stmt.executeUpdate("insert into EmployeTable values("+id+",'"+name+"',"+salary+")");
	System.out.println(i);
		}
		 catch (Exception e) {
			
			try {
				throw new AlreadyExistingEmployeeNumberException("employee id is already existing");
			} catch (AlreadyExistingEmployeeNumberException e1) {
				out.println(e1.getErrorMessage());
			}
			}
	}

}
