package com.virtusa.userdetails.model;

import java.io.Serializable;

public class User implements Serializable {

	private String firstName;
	private String lastName;
	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", phoneNum=" + phoneNum + "]";
	}
	private String emailId;
	private String phoneNum;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public User(String firstName, String lastName, String emailId,
			String phoneNum) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.phoneNum = phoneNum;
	}
	
}
