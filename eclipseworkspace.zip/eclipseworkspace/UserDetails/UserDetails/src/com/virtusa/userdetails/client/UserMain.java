package com.virtusa.userdetails.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.virtusa.userdetails.model.User;

public class UserMain {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		System.out.println("Enter first name");
		Scanner sn=new Scanner(System.in);
		String fname=sn.nextLine();
		System.out.println("Enter last name");
		String lname=sn.nextLine();
		System.out.println("Enter email id");
		String email=sn.nextLine();
		System.out.println("Enter contact number");
		String phone=sn.nextLine();
		User u=new User(fname,lname,email,phone);
		FileOutputStream fos=new FileOutputStream("c:\\users\\pavan\\Desktop\\text5.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
        oos.writeObject(u);
        FileInputStream fis=new FileInputStream("c:\\users\\pavan\\Desktop\\text5.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		Object obj=ois.readObject();
		System.out.println((User)obj);
	}

}
