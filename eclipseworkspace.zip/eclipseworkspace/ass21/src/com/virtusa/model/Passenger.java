package com.virtusa.model;

public class Passenger {
	public String pname;
	public String page;
	public String gender;
	public String phoneno;
	public String email;

	public Passenger() {
	}

	public Passenger(String pname, String page, String gender, String phoneno,
			String email) {
		this.pname = pname;
		this.page = page;
		this.gender = gender;
		this.phoneno = phoneno;
		this.email = email;
	}

}
