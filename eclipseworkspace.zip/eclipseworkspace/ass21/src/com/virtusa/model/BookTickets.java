package com.virtusa.model;

public interface BookTickets {

	public void bookTicket();

	public void cancelTiccket(long p);

}
