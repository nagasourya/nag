package com.virtusa.service;

import java.util.Random;
import java.util.Scanner;

import com.virtusa.model.BookTickets;

public class Book implements BookTickets {

	public long pnr;
	public int maxseats = 200;

	public void bookTicket() {

		Random rn = new Random();
		Long pnr = rn.nextLong();
		Scanner s3 = new Scanner(System.in);
		System.out.println("enter the origin");
		String o = s3.nextLine();
		System.out.println("enter the destination");
		String d = s3.nextLine();
		System.out.println("enter the boarding date");
		String bd = s3.nextLine();
		System.out.println("enter the no of tickets");
		int not = s3.nextInt();
		if (not <= maxseats) {
			System.out.println("Tickets Available");
			System.out.println("Do u want to book the tickets:Enter yes or no");
			Scanner sc1 = new Scanner(System.in);
			String reply1 = sc1.nextLine();
			if (reply1.equals("yes")) {
				System.out.println("No. of Tickets booked:" + not);
				maxseats = maxseats - not;
				System.out.println("Tickets:" + maxseats);
				System.out.println("Your PNR status are" + pnr);
				System.out
						.println("Do u want to cancel the tickets:Enter yes or no");
				Scanner sc2 = new Scanner(System.in);

				String rply = sc2.nextLine();
				if (rply.equals("yes"))
					cancelTiccket(pnr);

			}
		}

	}

	public void cancelTiccket(long p) {
		System.out.println("Enter PNR no");
		Scanner s3 = new Scanner(System.in);
		long PNR = Long.parseLong(s3.nextLine());
		//System.out.println("HAHA");
		if (PNR == p) {
			System.out.println("Enter no. of tickets to cancel");
			Scanner sc4 = new Scanner(System.in);
			int ticket = sc4.nextInt();
			maxseats = maxseats + ticket;
			System.out.println("Enter no. of tickets available" + maxseats);
		}

	}

}
