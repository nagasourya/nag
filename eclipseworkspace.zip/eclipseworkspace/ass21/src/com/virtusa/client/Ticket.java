package com.virtusa.client;

import java.util.Random;
import java.util.Scanner;

import com.virtusa.model.BookTickets;
import com.virtusa.model.Passenger;
import com.virtusa.service.Book;

public class Ticket {

	public static void main(String args[]) {

		Passenger p = new Passenger();

		Scanner s = new Scanner(System.in);
		System.out.println("enter passenger name");
		String pname = s.nextLine();
		System.out.println("enter passenger age");
		String page = s.nextLine();
		System.out.println("enter passenger gender");
		String pgen = s.nextLine();
		System.out.println("enter passenger contact no");
		String pcon = s.nextLine();
		System.out.println("enter passenger email");
		String pemail = s.nextLine();
		p = new Passenger(pname, page, pgen, pcon, pemail);

		Book b = new Book();

		System.out.println("Do you want to book enter yes for 1 and no for 2");
		Scanner s1 = new Scanner(System.in);
		String r = s1.nextLine();
		if (r.equals("1")) {
			b.bookTicket();
		} else {
			System.out.println("Exit");
		}

	}

}
