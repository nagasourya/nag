package com.virtusa.empdetails;

import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpManip {

	public static void main(String[] args) {
     Configuration cfg=new Configuration();
     cfg.configure("hibernate.cfg.xml");
     SessionFactory fac=cfg.buildSessionFactory();
     Session session=fac.openSession();
     
   
     
     
     Transaction t=session.beginTransaction();
     Empdetail e1=new Empdetail();
     e1.setId(101);
     e1.setFirstName("sravani");
     e1.setLastName("Vuppala");
     session.persist(e1);
     t.commit();
     session.close();
     System.out.println("Successfully completed my first hibernate program");
	}

}
