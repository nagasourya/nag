package com.virtusa.personapp.model;

public class PersonDetail {

	private String name;
	private int age;

	public PersonDetail() {

	}

	public PersonDetail(String name, int age) {
		this.age = age;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
