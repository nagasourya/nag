package com.virtusa.personapp.client;

import java.util.ArrayList;
import java.util.List;

import com.virtusa.personapp.model.PersonDetail;

public class PersonServices {
	private List<PersonDetail> pList = new ArrayList<PersonDetail>();

	public void addPerson(PersonDetail person) {
		pList.add(person);
	}

	public void display() {
		for (int i = 0; i < pList.size(); i++) {
			if (pList.get(i).getAge() <= 0) {
				pList.remove(i);
				i--;
			} else {
				System.out.println(pList.get(i));
			}
		}
	}
}
