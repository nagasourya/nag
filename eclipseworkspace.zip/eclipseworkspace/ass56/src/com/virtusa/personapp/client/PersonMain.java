package com.virtusa.personapp.client;

import java.util.Scanner;

import com.virtusa.personapp.model.PersonDetail;

public class PersonMain {

	public static void main(String[] args) {
		final PersonServices Ps = new PersonServices();

		Thread add = new Thread(new Runnable() {

			@Override
			public void run() {
				int condition = 4;
				while (condition > 0) {
					condition--;
					// TODO Auto-generated method stub
					System.out.println("Enter your name");
					Scanner scanner = new Scanner(System.in);
					String n = scanner.nextLine();
					System.out.println("Enter your age");
					int a = scanner.nextInt();
					PersonDetail person = new PersonDetail(n, a);
					Ps.addPerson(person);
				}
			}

		});

		Thread display = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println("Inside display thread...");
				Ps.display();

			}

		});

		add.start();
		try {
			add.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		display.start();

	}

}
