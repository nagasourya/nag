package com.virtusa.colorslistmain.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class ColorsListMain {

	/**
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		ArrayList<String> colors = new ArrayList<String>();
		colors.add("Orange");
		colors.add("Pink");
		colors.add("Purple");
		colors.add("violet");
		colors.add("green");
		colors.add("yellow");
		colors.add("black");
		// System.out.println(colors);

		FileWriter fw1 = new FileWriter("colors.txt");

		for (String c : colors)
			fw1.write("\n" + c);
		fw1.close();
		String s;
		FileReader fr1 = new FileReader("colors.txt");
		BufferedReader bf1 = new BufferedReader(fr1);
		System.out.println("The colors list");
		while ((s = bf1.readLine()) != null) {
			System.out.println(s);
		}

	}

}
