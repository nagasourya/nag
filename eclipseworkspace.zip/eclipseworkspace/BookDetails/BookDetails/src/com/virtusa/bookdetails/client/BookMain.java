package com.virtusa.bookdetails.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.virtusa.bookdetails.model.Books;



public class BookMain {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		Books b=new Books("java","Sridhar",1000);
		Books b1=new Books("java1","Sridhar1",11000);
		Books b2=new Books("java2","Sridhar2",11000);
		FileOutputStream fos=new FileOutputStream("C:\\Users\\sravaniv@virtusa.com\\Desktop\\bdetails.txt");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
        oos.writeObject(b);
        oos.writeObject(b1);
        oos.writeObject(b2);
    	FileInputStream fis=new FileInputStream("c:\\users\\pavan\\Desktop\\text3.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
        Object obj=ois.readObject();
        Object ob1=ois.readObject();
        Object ob2=ois.readObject();
        System.out.println((Books)obj);
        System.out.println((Books)ob1);
        System.out.println((Books)ob2);
	}

}
