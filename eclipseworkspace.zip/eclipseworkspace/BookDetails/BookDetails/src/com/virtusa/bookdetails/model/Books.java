package com.virtusa.bookdetails.model;

import java.io.Serializable;

public class Book implements Serializable {

	private String bookTitle;
	private String author;
	private int price;
	public Books(String bookTitle, String author, int price) {
		super();
		this.bookTitle = bookTitle;
		this.author = author;
		this.price = price;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	@Override
	public String toString() {
		return "Books [bookTitle=" + bookTitle + ", author=" + author
				+ ", price=" + price + "]";
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
