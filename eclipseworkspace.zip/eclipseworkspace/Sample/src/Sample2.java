import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.TreeSet;

public class Sample2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		TreeSet<Employee> ts = new TreeSet<Employee>(new Comp());

		ts.add(new Employee(1, "Sravani", "Technology", 900.0, null));
		ts.add(new Employee(2, "swarna", "Associate", 700.0, null));
		System.out.println(ts);
	}

}
