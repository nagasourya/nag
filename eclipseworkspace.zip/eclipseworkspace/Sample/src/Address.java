
public class Address {
	public String streetname;
	public String city;
	public int zipcode;
public Address(String sn,String c,int zip)
{
	streetname=sn;
	city=c;
	zipcode=zip;
}

}
