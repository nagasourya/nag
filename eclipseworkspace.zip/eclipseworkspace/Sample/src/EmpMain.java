
public class EmpMain {
	public static void main(String args[]){
	Address ad=new Address("Dwarkanagar","Vizag",530);
	
	Employee e=new Employee(101,"sravani","It",400.0,ad);
	e.toString();
	}	

}
