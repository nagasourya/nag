
public class Employee 
{
	
	private int empid;
    private String empname;
    private String designation;
	private Double salary;
	public Address adr;
	public Employee(int empid, String empname, String designation,
			Double salary, Address adr) 
	{
		 
		this.empid = empid;
		this.empname = empname;
		this.designation = designation;
		this.salary = salary;
		this.adr = adr;
	}
	
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empname=" + empname
				+ ", designation=" + designation + ", salary=" + salary
				+ ", adr=" + adr + "]";
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}

}
