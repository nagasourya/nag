import java.util.Scanner;


public class Emp {
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("first name");
		String fname=s.nextLine();
		System.out.println("Last name");
		String lname=s.nextLine();
		System.out.println("email");
		String email=s.nextLine();
		System.out.println("phoneno");
		String phoneno=s.nextLine();
		Validation v=new Validation();
		if(v.testEmail(email)&&v.testPhoneNo(phoneno))
		{
			System.out.println("firstname\n"+fname+"\nlast name\n"+lname+"\nemail\n"+email+"\nphone number\n"+phoneno);
		}
		else
		{
			System.out.println("enetr valid email/phone number");
		}
		
	}

}
