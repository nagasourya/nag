
public class Validation {

	
		    public boolean testPhoneNo(String PhoneNo)
		    {
		    	int length=PhoneNo.length();
		        boolean chackdec=PhoneNo.matches("\\d{10}");
		        boolean lendec=(length==10);
		        if(lendec&&chackdec)
		        {
		       	  return true;
		         }
		          return false;
		      }
		    public boolean testEmail(String Email)
		    {
		    	int atpos=Email.lastIndexOf('@');
		    	int dotpos=Email.lastIndexOf('.');
		    	boolean dec1=(dotpos!=-1);
		    	boolean dec2=(atpos!=-1);
		    	boolean dec=dec1 && dec2;
		    	int len=Email.length();
		    	int cond=dotpos-atpos;
		    	int cond1=len-dotpos;
		    	if(dec)
		    	{
		    		if(cond>0&&cond1>0)
		    		{
		    			return true;
		    		}
		    		
		    	}
		    	return false;
		    }
		    
		    }

