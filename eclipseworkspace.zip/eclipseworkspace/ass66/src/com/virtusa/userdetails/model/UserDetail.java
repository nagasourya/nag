package com.virtusa.userdetails.model;

import java.io.Serializable;

public class UserDetail implements Serializable {
	private String fName;
	private String lName;
	private String emailId;

	@Override
	public String toString() {
		return "UserDetail [fName=" + fName + ", lName=" + lName + ", emailId="
				+ emailId + ", phNum=" + phNum + "]";
	}

	public UserDetail(String fName, String lName, String emailId, String phNum) {
		super();
		this.fName = fName;
		this.lName = lName;
		this.emailId = emailId;
		this.phNum = phNum;
	}

	private String phNum;

}
