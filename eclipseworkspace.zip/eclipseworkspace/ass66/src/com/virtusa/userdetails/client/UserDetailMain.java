package com.virtusa.userdetails.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.virtusa.userdetails.model.UserDetail;

public class UserDetailMain {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		System.out.println("Enter first name");
		Scanner sn = new Scanner(System.in);
		String fname = sn.nextLine();
		System.out.println("Enter last name");
		String lname = sn.nextLine();
		System.out.println("Enter email id");
		String email = sn.nextLine();
		System.out.println("Enter contact number");
		String phone = sn.nextLine();
		UserDetail u = new UserDetail(fname, lname, email, phone);
		FileOutputStream fos = new FileOutputStream(
				"C:\\Users\\sravaniv@virtusa.com\\Desktop\\details.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(u);
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\sravaniv@virtusa.com\\Desktop\\details.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);

		Object obj = ois.readObject();
		System.out.println("The User DEtails are");
		System.out.println((UserDetail) obj);

	}

}
