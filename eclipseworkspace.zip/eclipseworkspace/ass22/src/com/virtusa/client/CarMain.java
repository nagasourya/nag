package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.model.Benz;
import com.virtusa.model.Toyato;
import com.virtusa.model.Pass;

public class CarMain {

	public static void main(String[] args) {

		Toyato t = new Toyato("1", "2000", " 8");
		Benz b = new Benz("2", "1500", "6");

		Scanner s = new Scanner(System.in);
		System.out.println("enter passenger details");
		System.out.println("enter passenger name");
		String name = s.nextLine();
		System.out.println("enter passenger location");
		String loc = s.nextLine();
		System.out.println("enter passenger phone");
		String phone = s.nextLine();
		Pass p = new Pass(name, loc, phone);
		System.out.println("Enter the Rental Car ");
		System.out.println("choose car 1.Benz 2.Toyato");
		String cno = s.nextLine();
		if (cno.equals("1")) {
			p.display();
			t.setModel();
			t.setPrice();
			t.setSeatingCapacity();

		} else if (cno.equals("2")) {
			p.display();
			b.setModel();
			b.setPrice();
			b.setSeatingCapacity();

		}

	}
}
