package com.virtusa.model;

public class Pass {
	public String name;
	public String location;
	public String phno;
	public String n;

	public Pass(String name, String location, String phno) {

		this.name = name;
		this.location = location;
		this.phno = phno;

	}

	public void display() {
		System.out.println("The details of passenger are");
		System.out.println(name);
		System.out.println(location);
		System.out.println(phno);

	}

}
