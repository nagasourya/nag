package com.virtusa.model;

public interface FourWheeler {
	public void setModel();

	public void setPrice();

	public void setSeatingCapacity();
}
