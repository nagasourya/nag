package com.virtusa.model;

public class Toyato implements FourWheeler {

	public String m;
	public String p;
	public String sc;
	public int c = 12;

	public Toyato(String m, String p, String sc) {
		super();
		this.m = m;
		this.p = p;
		this.sc = sc;
	}

	public void setModel() {
		System.out.println("The model is" + m);

	}

	public void setPrice() {
		System.out.println("The basic price is" + p);

	}

	public void setSeatingCapacity() {
		System.out.println("The seating capacity is" + sc);

	}

}
