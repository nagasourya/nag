package com.virtusa.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.dbutility.OracleConnection;
import com.virtusa.exceptions.*;

/**
 * Servlet implementation class EmployeeLogin
 */
@WebServlet("/EmployeeLogin")
public class EmployeeLogin extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int empid = Integer.parseInt(request.getParameter("empid"));
		String empname = request.getParameter("empname");
		String pwd =request.getParameter("emppass");
		try {
			Connection conn = OracleConnection.getConnection();
			out.println("Connection  " + conn);
			Statement stmt = conn.createStatement();
			int i = stmt.executeUpdate("insert into employees values(" + empid
					+ ",'" + empname + "'," + sal + ")");
			System.out.println(i);
		} catch (SQLException e) {

			try {
				throw new InvalidExistIdException(
						"employee id is already existing");
			} catch (InvalidExistIdException e1) {
				out.println(e1.getErrorMessage());
			}
			

		}

	}

}
