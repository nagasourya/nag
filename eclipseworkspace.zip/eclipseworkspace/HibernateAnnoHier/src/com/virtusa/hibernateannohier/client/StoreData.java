package com.virtusa.hibernateannohier.client;

import org.hibernate.*;  
import org.hibernate.cfg.*;  

import com.virtusa.hibernateannohier.model.Contract_Employee;
import com.virtusa.hibernateannohier.model.Employee;
import com.virtusa.hibernateannohier.model.Regular_Employee;
  
public class StoreData {  
public static void main(String[] args) {  
    AnnotationConfiguration cfg=new AnnotationConfiguration();  
    Session session=cfg.configure("hibernate.cfg.xml").buildSessionFactory().openSession();  
      
    Transaction t=session.beginTransaction();  
      
    Employee e1=new Employee();  

    e1.setName("sonoo1");  
      
    Regular_Employee e2=new Regular_Employee(); 

    e2.setName("Vivek Kumar1");  
    e2.setSalary(500001);  
    e2.setBonus(51);  
      
    Contract_Employee e3=new Contract_Employee();  

    e3.setName("Arjun Kumar1");  
    e3.setPay_per_hour(10001);  
    e3.setContract_duration("15 hours1");  
      
    session.persist(e1);  
    session.persist(e2);  
    session.persist(e3);  
      
    t.commit();  
    session.close();  
    System.out.println("success");  
}  
}  
