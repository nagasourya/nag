import java.util.Scanner;

public class EmployeeMain {

	public static void main(String args[]) {
		int empId;
		String empName;
		String empDesi;
		Double salary;

		int depId;
		String depName;
		String location;

		Scanner s1 = new Scanner(System.in);
		System.out.println("Enter empid");
		String sempId = s1.nextLine();
		System.out.println("Enter name");
		empName = s1.nextLine();
		System.out.println("Enter designation");
		empDesi = s1.nextLine();
		System.out.println("Enter Salary");
		String ssalary = s1.nextLine();
		empId = Integer.parseInt(sempId);
		System.out.println("Enter Depid");
		String dep = s1.nextLine();
		System.out.println("Enter Dep Name");
		depName = s1.nextLine();
		System.out.println("Enter Location");
		location = s1.nextLine();
		depId = Integer.parseInt(dep);

		System.out.println(empId);
		System.out.println(empName);
		System.out.println(empDesi);
		salary = Double.parseDouble(ssalary);
		System.out.println(salary);

		Department de = new Department();
		de.setDepId(depId);
		de.setDepName(depName);
		de.setLocation(location);
		System.out.println(de.getDepId());
		System.out.println(de.getDepName());
		System.out.println(de.getLocation());
		System.out.println(de.getEmp());

		Employee e = new Employee();
		e.setEmpid(empId);
		e.setEmpname(empName);
		e.setDesignation(empDesi);
		e.setSalary(salary);
		double d = e.annSal(salary);
		System.out.println(d);
		SysAdmin sys = new SysAdmin();
		sys.assignEmp(e.getEmpid());

	}
}
