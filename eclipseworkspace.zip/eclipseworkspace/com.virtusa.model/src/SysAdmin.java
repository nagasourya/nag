public class SysAdmin {

	public void assignEmp(int e) {
		Department d = new Department();
		d.setEmp(e);

	}
}
