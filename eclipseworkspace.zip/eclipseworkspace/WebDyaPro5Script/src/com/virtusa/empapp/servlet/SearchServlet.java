package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.dbutility.OracleConnection;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		try{
			String name=request.getParameter("empname"); 
			Connection con=OracleConnection.getConnection();
			String q="select * from emp where empname like('%'||?||'%')";
			PreparedStatement pstmt=con.prepareStatement(q);
			  pstmt.setString(1,name);
			
			ResultSet rs=pstmt.executeQuery();
			out.println("<html><head></head><body>");
			out.println("<table><tr><td>EmployId</td><td>EmployName</td><td>EmployPassword</td><td>Salary</td><td>DepId</td></tr>");
			while(rs.next())
			{
				out.println("<tr>");
				
				out.println("<td>"+rs.getInt(1)+"</td>");
				out.println("<td>"+rs.getString(2)+"</td>");
				out.println("<td>"+rs.getString(3)+"</td>");
				out.println("<td>"+rs.getInt(4)+"</td>");
				out.println("<td>"+rs.getInt(5)+"</td>");
				
				out.println("</tr>");
			}
			pstmt.close();
			con.close();
		}catch(Exception e){out.println(e);}
	}


}
