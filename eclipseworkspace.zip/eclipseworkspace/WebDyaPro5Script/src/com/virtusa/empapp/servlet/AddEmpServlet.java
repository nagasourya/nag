package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.services.EmpOperationsImpl;


/**
 * Servlet implementation class AddEmpServlet
 */
@WebServlet("/AddEmpServlet")
public class AddEmpServlet extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
//		Cookie[] cookies=request.getCookies();
// 		for(Cookie cookie : cookies){
// 		        if(cookie.getName().equals("userid"))
// 		        out.println(co/okie.getName()+":"+cookie.getValue());
// 		    }
		int empid = Integer.parseInt(request.getParameter("empid"));
		String empname = request.getParameter("empname");
		String emppass= request.getParameter("emppass");
		double sal=Double.parseDouble(request.getParameter("empsal"));
		// String depname = request.getParameter("depname");
		EmpDetails emp=new EmpDetails();
		emp.setEmpId(empid);
		emp.setEmpName(empname);
		emp.setPassword(emppass);
		emp.setSalary(sal);
        emp.setDepId(Integer.parseInt(request.getParameter("depname")));
//		try{
//
//			
//		Connection conn = com.virtusa.empapp.dbutility.OracleConnection.getConnection();
//      String q = "Select * from department where depname=? ";
//	PreparedStatement pstmt=conn.prepareStatement(q);
//	  pstmt.setString(1,depname);
//			
//	ResultSet rs=pstmt.executeQuery();
//	while(rs.next()){
//		emp.setDepId(rs.getInt(1));
//		System.out.println(rs.getString(2));
//        	}
	    EmpOperationsImpl eoi=new EmpOperationsImpl();
	   int i;
	try {
		i = eoi.addEmployee(emp);
	
	   if(i==1)
	   {
		   out.println("Added successfully");
		   
		   
	   }
	   else{
		   out.println("not addded");
	   }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
//	   pstmt.close();
//		conn.close();
//	
//		}
//		catch(SQLException s)
//		{
//			s.printStackTrace();
//		}
		RequestDispatcher dispatch=request.getRequestDispatcher("Hr.jsp");
	
   	 dispatch.include(request, response);
		
	}

}
