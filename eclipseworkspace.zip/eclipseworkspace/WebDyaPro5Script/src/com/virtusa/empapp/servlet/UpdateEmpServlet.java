package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.services.EmpOperationsImpl;

@WebServlet("/UpdateEmpServlet")
public class UpdateEmpServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		/*Cookie[] cookies=request.getCookies();
 		for(Cookie cookie : cookies){
 		        
 		        out.println(cookie.getName()+":"+cookie.getValue());
 		    }*/
		int empid = Integer.parseInt(request.getParameter("empid"));
		String empname = request.getParameter("empname");
		String emppass = request.getParameter("emppass");
		String sal = request.getParameter("empsal");
		
		String depid =request.getParameter("empdepid");
		//out.println(sal);
		EmpDetails emp = new EmpDetails();
		emp.setEmpId(empid);
		try {

			Connection conn = com.virtusa.empapp.dbutility.OracleConnection
					.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("Select * from emp where empid="
					+ empid + " ");
			while (rs.next()) {
				if (empname.equals("")) {
					emp.setEmpName(rs.getString(2));
				} else {
					emp.setEmpName(empname);
				}
				if (emppass.equals(" ")) {
					emp.setPassword(rs.getString(3));
				} else {
					emp.setPassword(rs.getString(3));
				}
				if (sal.equals("")) {
					emp.setSalary(rs.getDouble(4));
				} else {
					emp.setSalary(Integer.parseInt(sal));
				}
				if (depid.equals("")) {
					emp.setDepId(rs.getInt(5));
				} else {
					emp.setDepId(Integer.parseInt(depid));
				}
				
			}
			  EmpOperationsImpl eoi=new EmpOperationsImpl();
			   int i=eoi.updateEmployee(emp);
			   if(i==1)
			   {
				   out.println("updated successfully");
			   }
			   else{
				   out.println("not updated");
			   }
			
		} catch (SQLException s) {
			s.printStackTrace();
		}
		RequestDispatcher dispatch=request.getRequestDispatcher("Hr.jsp");
		
	   	 dispatch.include(request, response);
			
	}
}
