package com.virtusa.empapp.services;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.empapp.model.DepDetails;
import com.virtusa.empapp.model.EmpDetails;

public interface EmpOperations {
	 int selectEmployee(EmpDetails emp) throws SQLException;
	 int addEmployee(EmpDetails emp) throws SQLException;
 int delEmployee(EmpDetails emp) throws SQLException;
	 int updateEmployee(EmpDetails emp) throws SQLException;
 List<EmpDetails> selectAllEmployee() throws SQLException;
 List<DepDetails> selectAllDep() throws SQLException;

}
