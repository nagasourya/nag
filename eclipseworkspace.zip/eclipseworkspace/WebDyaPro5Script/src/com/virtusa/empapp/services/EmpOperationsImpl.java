package com.virtusa.empapp.services;
import com.virtusa.empapp.dbutility.OracleConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.empapp.dbutility.OracleConnection;
import com.virtusa.empapp.model.DepDetails;
import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.servlet.AddEmpServlet;

public class EmpOperationsImpl implements EmpOperations {
          
	
		int depid=0;

	public int selectEmployee(EmpDetails emp) throws SQLException {
		try{
		Connection con=OracleConnection.getConnection();
		System.out.println(con);
	PreparedStatement pstmt=con.prepareStatement("select * from emp where empid=? and password=? ");
	pstmt.setInt(1,emp.getEmpId());
	pstmt.setString(2,emp.getPassword());
	
		
	ResultSet rs=pstmt.executeQuery();
	if(rs.next())
	{
	depid=rs.getInt(5);
	return depid;
	}
	
	pstmt.close();
	con.close();
	}
		catch(Exception e){System.out.println(e);}
	    
		return depid;
	}

	@Override
	public int addEmployee(EmpDetails emp) throws SQLException {
		Connection con=OracleConnection.getConnection();
		int empid=emp.getEmpId();
		String empname=emp.getEmpName();
		String emppass=emp.getPassword();
		double sal=emp.getSalary();
		int depid=emp.getDepId();
		String q="insert into emp values(?,?,?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(q);
     
        pstmt.setInt(1, empid);
		pstmt.setString(2, empname);
		pstmt.setString(3, emppass);
		pstmt.setDouble(4, sal);
		pstmt.setInt(5,depid);
		   int i=pstmt.executeUpdate();
		pstmt.close();
		con.close();
		System.out.println(i);
		return i;
		
	}
	@Override
	public int delEmployee(EmpDetails emp) throws SQLException {
		Connection con=OracleConnection.getConnection();
	
		int empid=emp.getEmpId();
		String q= "delete from emp where empid=? ";
		PreparedStatement pstmt=con.prepareStatement(q);
		  pstmt.setInt(1, empid);
			
        int i=pstmt.executeUpdate();
		pstmt.close();
		con.close();
		return i;
	}

	public int updateEmployee(EmpDetails emp) throws SQLException {
	
		Connection con=OracleConnection.getConnection();
	
		int empid=emp.getEmpId();
		String empname=emp.getEmpName();
		String emppass=emp.getPassword();
		double sal=emp.getSalary();
		int depid=emp.getDepId();
	String q="update emp set empname=?,password=?,salary=?,depid=? where empid=?";
	PreparedStatement pstmt=con.prepareStatement(q);
	  pstmt.setInt(5, empid);
			pstmt.setString(1, empname);
			pstmt.setString(2, emppass);
			pstmt.setDouble(3, sal);
			pstmt.setInt(4,depid);
    int i=pstmt.executeUpdate();	
    
	pstmt.close();
		con.close();
		return i;
	}

	public List<EmpDetails> selectAllEmployee() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<EmpDetails> arrl=new ArrayList<EmpDetails>();
		Connection con=OracleConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from emp");
		while(rs.next())
		{
			EmpDetails emp=new EmpDetails();
			emp.setEmpId(rs.getInt(1));
			emp.setEmpName(rs.getString(2));
			emp.setPassword(rs.getString(3));
			emp.setSalary(rs.getDouble(4));
			emp.setDepId(rs.getInt(5));
			arrl.add(emp);
			
		}
		stmt.close();
		con.close();
		return arrl;
	}

	@Override
	public List<DepDetails> selectAllDep() throws SQLException {
		ArrayList<DepDetails> arrl=new ArrayList<DepDetails>();
		Connection con=OracleConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from department");
		while(rs.next())
		{
			DepDetails dep=new DepDetails();
			dep.setDepId(rs.getInt(1));
			dep.setDepName(rs.getString(2));
			arrl.add(dep);
		}
		stmt.close();
		con.close();
		return arrl;
	}

}
