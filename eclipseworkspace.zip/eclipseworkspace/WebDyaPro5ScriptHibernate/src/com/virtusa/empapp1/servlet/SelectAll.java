package com.virtusa.empapp1.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp1.model.EmpDetails;
import com.virtusa.empapp1.services.EmpOperationsImpl;
/**
 * Servlet implementation class ServletAll
 */
@WebServlet("/SelectAll")
public class SelectAll extends HttpServlet {
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      List<EmpDetails> emplist;
	      EmpOperationsImpl eoi=new EmpOperationsImpl();
	      try {
			emplist=eoi.selectAllEmployee();
			RequestDispatcher dispatch=request.getRequestDispatcher("SelectAll.jsp");
		request.setAttribute("emplist",emplist);
	    dispatch.include(request, response);
	      }
	      catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
