package com.virtusa.empapp1.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.empapp1.model.EmpDetails;
import com.virtusa.empapp1.services.EmpOperationsImpl;

@WebServlet("/UpdateEmpServlet")
public class UpdateEmpServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
	
	      System.out.println("hai");
		String empid = request.getParameter("empid");
		 System.out.println("hai1");
		String empname = request.getParameter("empname");
		String emppass = request.getParameter("emppass");
		String sal = request.getParameter("empsal");
		
		String depid =request.getParameter("empdepid");
		//out.println(sal);
		EmpDetails emp = new EmpDetails();
		emp.setEmpId(Integer.parseInt(empid));
		try {

			Configuration cfg= new Configuration();
 	      cfg.configure("hibernate.cfg.xml");
		  SessionFactory fac=cfg.buildSessionFactory();
			Session session=fac.openSession();
 		  Transaction t=session.beginTransaction();
 		  String hql="from EmpDetails where empId=:empid1";
 		  Query query=session.createQuery(hql);
 		  query.setParameter("empid1", Integer.parseInt(empid));
 		  EmpDetails emp1=(EmpDetails) query.uniqueResult();
		  
				if (empname.equals("")) {
					emp.setEmpName(emp1.getEmpName());
				} else {
					emp.setEmpName(empname);
				}
				if (emppass.equals(" ")) {
					emp.setPassword(emp1.getPassword());
				} else {
					emp.setPassword(emppass);
				}
				if (sal.equals("")) {
					emp.setSalary(emp1.getSalary());
				} else {
					emp.setSalary(Double.parseDouble(sal));
				}
				if (depid.equals("")) {
					emp.setDepId(emp1.getDepId());
				} else {
					emp.setDepId(Integer.parseInt(depid));
				}
				System.out.println("hai");
			
			  EmpOperationsImpl eoi=new EmpOperationsImpl();
			   int i=eoi.updateEmployee(emp);
			   if(i==1)
			   {
				   out.println("updated successfully");
			   }
			   else{
				   out.println("not updated");
			   }
			
		} catch (SQLException s) {
			s.printStackTrace();
		}
		RequestDispatcher dispatch=request.getRequestDispatcher("Hr.jsp");
		
	   	 dispatch.include(request, response);
			
	}
}
