package com.virtusa.empapp1.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.empapp1.dbutility.OracleConnection;
import com.virtusa.empapp1.model.EmpDetails;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html");
		
		PrintWriter out=response.getWriter();
		try{
			String name=request.getParameter("empname"); 

		       Configuration cfg=new Configuration();
		       cfg.configure("hibernate.cfg.xml");
		       SessionFactory fac=cfg.buildSessionFactory();
		       Session session=fac.openSession();
		       Transaction t=session.beginTransaction();
		   	String hql="from EmpDetails where empName like :empname";
		       Query query = session.createQuery(hql);
		       query.setParameter("empname","%"+name+"%");
		       List<EmpDetails> list=query.list();
		       Iterator<EmpDetails> i=list.iterator();
			out.println("<html><head></head><body>");
			out.println("<table><tr><td>EmployId</td><td>EmployName</td><td>EmployPassword</td><td>Salary</td><td>DepId</td></tr>");
			while(i.hasNext())
			{
				
				EmpDetails e=(EmpDetails)i.next();
				out.println("<tr>");
				
				out.println("<td>"+e.getEmpId()+"</td>");
				out.println("<td>"+e.getPassword()+"</td>");
				out.println("<td>"+e.getEmpName()+"</td>");
				out.println("<td>"+e.getSalary()+"</td>");
				out.println("<td>"+e.getDepId()+"</td>");
				
				out.println("</tr>");
		    }
		}
			catch(Exception e){out.println(e);}
	
}
}
