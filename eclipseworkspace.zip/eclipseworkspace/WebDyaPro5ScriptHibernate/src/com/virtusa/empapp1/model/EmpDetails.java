package com.virtusa.empapp1.model;

public class EmpDetails {
	private int empId;
	private String empName;
	private String password;
	private double salary;
	private int depId;
	public EmpDetails(int empId, String empName, String password,
			double salary, int depId) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.password = password;
		this.salary = salary;
		this.depId = depId;
	}
	public EmpDetails() {
		// TODO Auto-generated constructor stub
	}
	
	public int getEmpId() {
		return empId;
	}
	@Override
	public String toString() {
		return "EmpDetails [empId=" + empId + ", empName=" + empName
				+ ", password=" + password + ", salary=" + salary + ", depId="
				+ depId + "]";
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getDepId() {
		return depId;
	}
	public void setDepId(int depId) {
		this.depId = depId;
	}

}
