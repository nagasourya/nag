package com.virtusa.empapp1.model;

public class DepDetails {
	private int depId;
	private String depName;
	public DepDetails(int depId, String depName) {
		super();
		this.depId = depId;
		this.depName = depName;
	}
final public int getDepId() {
		return depId;
	}
	final public void setDepId(int depId) {
		this.depId = depId;
	}
	final public String getDepName() {
		return depName;
	}
	 public DepDetails() {
		super();
	}
	final public void setDepName(String depName) {
		this.depName = depName;
	}
	@Override
	final public String toString() {
		return "DepDetails [depId=" + depId + ", depName=" + depName + "]";
	}
	

}
