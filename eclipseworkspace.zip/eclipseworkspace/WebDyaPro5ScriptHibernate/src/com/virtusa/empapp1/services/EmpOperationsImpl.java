package com.virtusa.empapp1.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



import com.virtusa.empapp1.dbutility.OracleConnection;
import com.virtusa.empapp1.model.DepDetails;
import com.virtusa.empapp1.model.EmpDetails;
import com.virtusa.empapp1.servlet.AddEmpServlet;

public class EmpOperationsImpl implements EmpOperations {
          
	
		int depid=0;

	public int selectEmployee(EmpDetails emp) throws SQLException {
		try{
	Configuration cfg= new Configuration();
	cfg.configure("hibernate.cfg.xml");
	SessionFactory fac=cfg.buildSessionFactory();
	Session session=fac.openSession();
	Transaction t=session.beginTransaction();
	String hql="From EmpDetails where empId=:eid and password=:pwd";
	Query query=session.createQuery(hql);
	query.setParameter("eid",emp.getEmpId());
	query.setParameter("pwd",emp.getPassword());
	
	EmpDetails em=(EmpDetails)query.uniqueResult();
	System.out.println("emp id is"+em+emp.getEmpId());
	depid=em.getDepId();
		
	
	}
		catch(Exception e){System.out.println(e);}
	    
		return depid;
	}

	@Override
	public int addEmployee(EmpDetails emp) throws SQLException {
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory fac=cfg.buildSessionFactory();
		Session session=fac.openSession();
		Transaction t=session.beginTransaction();
		session.persist(emp);
		t.commit();
		return 1;
		
	}
	@Override
	public int delEmployee(EmpDetails emp) throws SQLException {
	         Configuration cfg=new Configuration();
	         cfg.configure("hibernate.cfg.xml");
	         SessionFactory fac=cfg.buildSessionFactory();
	         Session session=fac.openSession();
	         Transaction t=session.beginTransaction();
		String hql= "delete from EmpDetails where empId=:id";
		Query query=session.createQuery(hql);
		query.setParameter("id", emp.getEmpId());
		int i=query.executeUpdate();
		t.commit();
		return i;
	}

	public int updateEmployee(EmpDetails emp) throws SQLException {
	
       Configuration cfg=new Configuration();
       cfg.configure("hibernate.cfg.xml");
       SessionFactory fac=cfg.buildSessionFactory();
       Session session=fac.openSession();
       Transaction t=session.beginTransaction();
       System.out.println("hai10");
	String hql="update EmpDetails set empName=:empname,password=:emppass,salary=:sal,depId=:depid where empId=:empid";
	Query query=session.createQuery(hql);
	query.setParameter("empname",emp.getEmpName());
	query.setParameter("emppass", emp.getPassword());
	query.setParameter("sal", emp.getSalary());
	query.setParameter("depid", emp.getDepId());
	query.setParameter("empid", emp.getEmpId());
    int i=query.executeUpdate();	 
    t.commit();
	
		return i;
	}

	public List<EmpDetails> selectAllEmployee() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<EmpDetails> arrl=new ArrayList<EmpDetails>();

	       Configuration cfg=new Configuration();
	       cfg.configure("hibernate.cfg.xml");
	       SessionFactory fac=cfg.buildSessionFactory();
	       Session session=fac.openSession();
	       Transaction t=session.beginTransaction();
		
		
    String hql="from EmpDetails";
    Query query=session.createQuery(hql);
    return arrl=(ArrayList<EmpDetails>)query.list();

	
	}

	@Override
	public List<DepDetails> selectAllDep() throws SQLException {
		ArrayList<DepDetails> arrl=new ArrayList<DepDetails>();

	       Configuration cfg=new Configuration();
	       cfg.configure("hibernate.cfg.xml");
	       SessionFactory fac=cfg.buildSessionFactory();
	       Session session=fac.openSession();
	       Transaction t=session.beginTransaction();
		
	   String hql="from DepDetails";
		Query query=session.createQuery(hql);
		arrl=(ArrayList<DepDetails>)query.list();
		return arrl;
	}

}
