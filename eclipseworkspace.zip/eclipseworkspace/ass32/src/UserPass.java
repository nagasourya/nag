import java.util.Scanner;

public class UserPass {

	public static void main(String[] args) throws InvalidCredentialsException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the username");
		String uid = sc.nextLine();

		System.out.println("Enter the password");
		String p = sc.nextLine();
		Validation v = new Validation();
		try {
			if (v.validUserPwd(uid, p)) {
				System.out.println("welcome to the user");
			} else {
				throw new InvalidCredentialsException("Not a Valid user");
			}
		} catch (InvalidCredentialsException ie) {
			System.err.println("there is a error " + ie);
		}

	}

}
