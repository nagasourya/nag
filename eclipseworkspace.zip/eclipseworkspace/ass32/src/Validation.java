public class Validation {

	public boolean validUserPwd(String u, String p) {
		String regnum = "^.*[0-9].*$";
		String pwd = "1234qwer$";
		int len = u.length();
		if (u.matches(regnum) && len >= 5 && p.equals(pwd)) {
			return true;
		} else {
			return false;
		}
	}

}
