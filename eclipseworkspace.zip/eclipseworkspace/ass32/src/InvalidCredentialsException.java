public class InvalidCredentialsException extends Exception {
	private String errorMessage;

	public InvalidCredentialsException(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
