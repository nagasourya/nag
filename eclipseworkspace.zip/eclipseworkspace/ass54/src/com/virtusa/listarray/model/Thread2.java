package com.virtusa.listarray.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Thread2 extends Thread {
	ArrayList<String> ar;

	public Thread2(ArrayList<String> ar) {
		super();
		this.ar = ar;
	}

	public void run() {
		Collections.reverse(ar);
		System.out.println("Thread2");
		for (String str : ar)
			System.out.println(str);
	}

}
