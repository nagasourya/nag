package com.virtusa.listarray.model;

import java.util.ArrayList;

public class Thread1 extends Thread {

	ArrayList<String> ar;

	public Thread1(ArrayList<String> ar) {
		super();
		this.ar = ar;
	}

	public void run() {
		System.out.println("Thread1");
		for (String str : ar)
			System.out.println(str);
	}

}
