package com.virtusa.listarray.client;

import java.util.ArrayList;

import com.virtusa.listarray.model.Thread1;
import com.virtusa.listarray.model.Thread2;

public class ThreadDemo {

	public static void main(String[] args) {
		ArrayList<String> a = new ArrayList();
		a.add("Hello");
		a.add("Awesome");
		a.add("Fabulous");
		a.add("Impressive");
		a.add("Marvallous");

		Thread1 t1 = new Thread1(a);
		t1.start();
		Thread2 t2 = new Thread2(a);
		t2.start();
	}

}
