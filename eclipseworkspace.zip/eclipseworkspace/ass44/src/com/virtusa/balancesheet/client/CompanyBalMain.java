package com.virtusa.balancesheet.client;

import java.util.HashMap;
import java.util.Scanner;

import com.virtusa.balancesheet.model.CompDetails;

public class CompanyBalMain {
	public static void main(String args[]) {

		HashMap<String, CompDetails> hm = new HashMap();
		hm.put("2011", new CompDetails(10000, 25000, 38000, 11000, "2011"));
		hm.put("2012", new CompDetails(14000, 25000, 34000, 11000, "2012"));
		hm.put("2013", new CompDetails(12500, 28000, 31000, 13000, "2013"));
		hm.put("2014", new CompDetails(16500, 24500, 32000, 17000, "2014"));
		hm.put("2015", new CompDetails(12500, 28000, 37000, 14000, "2015"));
		System.out.println("Enter the Key");
		Scanner sc = new Scanner(System.in);
		String ykey = sc.nextLine();
		System.out.println(hm.get(ykey));

	}

}
