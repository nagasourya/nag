package com.virtusa.balancesheet.model;

public class CompDetails {
	private int ehs;
	private int security;
	private int it;
	private int publisher;
	private String year;
	private long tot;

	public CompDetails(int ehs, int security, int it, int publisher, String year) {
		super();
		this.ehs = ehs;
		this.security = security;
		this.it = it;
		this.publisher = publisher;
		this.year = year;
		tot = ehs + security + it + publisher;
	}

	@Override
	public String toString() {
		return "CompDetails [tot=" + tot + "]";
	}

}
