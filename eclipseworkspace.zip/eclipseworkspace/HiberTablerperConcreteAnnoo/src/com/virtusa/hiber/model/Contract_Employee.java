package com.virtusa.hiber.model;

import javax.persistence.AssociationOverride;
import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="ctpc12")
@AttributeOverrides({
	@AttributeOverride(name="cId",column=@Column(name="Id")),
	@AttributeOverride(name="cName",column=@Column(name="Name"))
})
public class Contract_Employee extends Employee {
	@Column(name="payperhour")
	private float payperhour;
	@Column(name="cont_duration")
	private String contractduration;

	public float getPayperhour() {
		return payperhour;
	}
	public void setPayperhour(float payperhour) {
		this.payperhour = payperhour;
	}
	public String getContractduration() {
		return contractduration;
	}
	public void setContractduration(String contractduration) {
		this.contractduration = contractduration;
	}

}
