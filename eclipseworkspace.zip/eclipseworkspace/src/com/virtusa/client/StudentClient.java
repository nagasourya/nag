package com.virtusa.client;

import com.virtusa.service.StudentDAOImpl;

public class StudentClient {

	public static void main(String[] args) {
		StudentDAOImpl sdao = new StudentDAOImpl();
		sdao.insertStudent(null);
		//call service methods
	}
}
