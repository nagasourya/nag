package com.virtusa.service;

import java.sql.Connection;

import com.virtusa.dbutil.OracleConnection;
import com.virtusa.model.Student;

public class StudentDAOImpl implements StudentDAO{

	@Override
	public int insertStudent(Student stu) {
		Connection conn = OracleConnection.getConnection();
		System.out.println("Connection  "+conn);
		//insert logic
		return 0;
	}

	@Override
	public int deleteStudent(int sId) {
		//delete logic
		return 0;
	}

}
