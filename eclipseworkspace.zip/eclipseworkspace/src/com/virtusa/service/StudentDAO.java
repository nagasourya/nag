package com.virtusa.service;

import com.virtusa.model.Student;

public interface StudentDAO {

		public int insertStudent(Student stu);
		public int deleteStudent(int sId);
}
