package com.virtusa.empdepdetails.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import com.virtusa.empdepdetails.mode.Comp;
import com.virtusa.empdepdetails.mode.DepartmentDetails;
import com.virtusa.empdepdetails.mode.EmployeeDetails;

public class EmpDepDetails {

	public static void main(String[] args) {
		HashMap<EmployeeDetails, DepartmentDetails> hm = new HashMap();
		hm.put(new EmployeeDetails("101", "sravani", "10000"),
				new DepartmentDetails("IT", "HYD"));
		hm.put(new EmployeeDetails("102", "aparna", "15000"),
				new DepartmentDetails("DSE", "BLR"));
		hm.put(new EmployeeDetails("103", "swapnika", "75000"),
				new DepartmentDetails("ASIT", "HYD"));
		hm.put(new EmployeeDetails("104", "sukanya", "85000"),
				new DepartmentDetails("ECE", "HYD"));
		hm.put(new EmployeeDetails("105", "tulasiram", "95000"),
				new DepartmentDetails("SHEM", "HYD"));
		hm.put(new EmployeeDetails("105", "tulasiram", "95000"),
				new DepartmentDetails("CHEM", "HYD"));

		TreeMap<EmployeeDetails, DepartmentDetails> tm = SortValue(hm);
		System.out.println(tm);

	}

	private static TreeMap<EmployeeDetails, DepartmentDetails> SortValue(
			HashMap<EmployeeDetails, DepartmentDetails> hm) {
		Comp vc = new Comp(hm);
		TreeMap<EmployeeDetails, DepartmentDetails> sortedMap = new TreeMap<EmployeeDetails, DepartmentDetails>(
				vc);
		sortedMap.putAll(hm);
		return sortedMap;

	}

}
