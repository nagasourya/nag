package com.virtusa.empdepdetails.mode;

public class EmployeeDetails {
	private String empId;
	private String empName;
	private String salary;

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", salary=" + salary + "]";
	}

	public EmployeeDetails(String empId, String empName, String salary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}
}
