package com.virtusa.empdepdetails.mode;

import java.util.Comparator;
import java.util.Map;

public class Comp implements Comparator<EmployeeDetails> {

	Map<EmployeeDetails, DepartmentDetails> map;

	public Comp(Map<EmployeeDetails, DepartmentDetails> map) {
		super();
		this.map = map;
	}

	@Override
	public int compare(EmployeeDetails a, EmployeeDetails b) {

		return map.get(a).getDepName().compareTo(map.get(b).getDepName());
	}

}
