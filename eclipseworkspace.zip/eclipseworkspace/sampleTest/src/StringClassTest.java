import org.junit.Assert;
import org.junit.Test;


public class StringClassTest {

	
		@Test
		public void StringTestLength()
	{
		Assert.assertEquals(5, "Hello".length());
	}


}
