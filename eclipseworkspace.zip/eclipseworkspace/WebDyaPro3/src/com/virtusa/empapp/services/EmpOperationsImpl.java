package com.virtusa.empapp.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.virtusa.empapp.dbutility.OracleConnection;
import com.virtusa.empapp.model.EmpDetails;

public class EmpOperationsImpl implements EmpOperations {
          
	
		int depid=0;

	public int selectEmployee(EmpDetails emp) throws SQLException {
		try{
		Connection con=OracleConnection.getConnection();
		System.out.println(con);
	PreparedStatement pstmt=con.prepareStatement("select * from emp where empid=? and password=? ");
	pstmt.setInt(1,emp.getEmpId());
	pstmt.setString(2,emp.getPassword());
	
		
	ResultSet rs=pstmt.executeQuery();
	if(rs.next())
	{
	depid=rs.getInt(5);
	return depid;
	}}catch(Exception e){System.out.println(e);}
	
		return depid;
	}

	@Override
	public int addEmployee(EmpDetails emp) throws SQLException {
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("insert into emp values("+emp.getEmpId()+",'"+emp.getEmpName()+"','"+emp.getPassword()+"',"+emp.getSalary()+","+emp.getDepId()+")");
		return i;
	}
	@Override
	public int delEmployee(EmpDetails emp) throws SQLException {
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("delete from emp where empid="+emp.getEmpId()+ "");
		return i;
	}

	public int updateEmployee(EmpDetails emp) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("update emp set empname='"+emp.getEmpName()+"',password='"+emp.getPassword()+"',salary="+emp.getSalary()+",depid="+emp.getDepId()+" where empid="+emp.getEmpId()+ "");
		return i;
	}


}
