package com.virtusa.empapp.services;

import java.sql.SQLException;

import com.virtusa.empapp.model.EmpDetails;

public interface EmpOperations {
	public int selectEmployee(EmpDetails emp) throws SQLException;
	public int addEmployee(EmpDetails emp) throws SQLException;
	public int delEmployee(EmpDetails emp) throws SQLException;
	public int updateEmployee(EmpDetails emp) throws SQLException;

}
