package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.dbutility.OracleConnection;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Cookie[] cookies=request.getCookies();
 		for(Cookie cookie : cookies){
 		        
 		        out.println(cookie.getName()+":"+cookie.getValue());
 		    }
		out.println("<html>");
		out.println("<head></head>");
		out.println("<body>");
		out.println("<center>");
		out.println("<h1>ADD EMPLOYEE</h1><br>");
		out.println("<form action=\"AddEmpServlet\" method=\"post\">");
		out.println("EmployeeID<input type=\"text\" name=\"empid\"><br>");
		out.println("EmployeeName<input type=\"text\" name=\"empname\"><br>");
		out.println("Password<input type=\"password\" name=\"emppass\"><br>");
		out.println("Salary<input type=\"text\" name=\"empsal\"><br>");
		try{
			
			 
			Connection conn = OracleConnection.getConnection();
		     System.out.println(conn);
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from department");
			out.println("<select name=\"depname\">");
			while(rs.next())
			{
		
		out.println("<option value="+rs.getString(2)+">"+rs.getString(2)+"</option>");

			}
			out.println("</select>");
			out.println("<input type=\"submit\" value=\"submit\">");
			out.println("<input type=\"reset\" value=\"reset\">");
			out.println("</form>");
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		}
		catch(Exception e){out.println(e);}
	}
	

	

}
