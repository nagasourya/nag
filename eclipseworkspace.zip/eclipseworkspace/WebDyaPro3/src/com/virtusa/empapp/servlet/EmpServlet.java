package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.services.EmpOperationsImpl;

/**
 * Servlet implementation class EmpServlet
 */
@WebServlet("/EmpServlet")
public class EmpServlet extends HttpServlet {

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			
			
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int empid = Integer.parseInt(request.getParameter("empid"));
		String password = request.getParameter("emppass");
		EmpDetails emp=new EmpDetails();
		emp.setEmpId(empid);
		emp.setPassword(password);
		Cookie userid=new Cookie("userid",""+emp.getEmpId());
		response.addCookie(userid);
		

		EmpOperationsImpl eoi=new EmpOperationsImpl();
	  int depid=eoi.selectEmployee(emp);
	     if(depid==101)
	     {
	    	
	    	 RequestDispatcher dispatch=request.getRequestDispatcher("Hr.html");
	    	 dispatch.include(request, response);
	    	 
	     }
	     else
	     {
	    	 RequestDispatcher dispatch=request.getRequestDispatcher("EmpLogin.html");
	    	 dispatch.forward(request, response);
	     }
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
