package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.services.EmpOperationsImpl;


/**
 * Servlet implementation class AddEmpServlet
 */
@WebServlet("/AddEmpServlet")
public class AddEmpServlet extends HttpServlet {
	
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Cookie[] cookies=request.getCookies();
 		for(Cookie cookie : cookies){
 		        
 		        out.println(cookie.getName()+":"+cookie.getValue());
 		    }
		int empid = Integer.parseInt(request.getParameter("empid"));
		String empname = request.getParameter("empname");
		String emppass= request.getParameter("emppass");
		double sal=Double.parseDouble(request.getParameter("empsal"));
		 String depname = request.getParameter("depname");
		EmpDetails emp=new EmpDetails();
		emp.setEmpId(empid);
		emp.setEmpName(empname);
		emp.setPassword(emppass);
		emp.setSalary(sal);

		try{

			
		Connection conn = com.virtusa.empapp.dbutility.OracleConnection.getConnection();
		Statement stmt = conn.createStatement();
	ResultSet rs = stmt.executeQuery("Select * from department where depname='"+depname+"' ");
	while(rs.next()){
		emp.setDepId(rs.getInt(1));
        	}
	    EmpOperationsImpl eoi=new EmpOperationsImpl();
	   int i=eoi.addEmployee(emp);
	   if(i==1)
	   {
		   out.println("Added successfully");
		   
	   }
	   else{
		   out.println("not addded");
	   }
	
	
		}
		catch(SQLException s)
		{
			s.printStackTrace();
		}
		RequestDispatcher dispatch=request.getRequestDispatcher("Hr.html");
	
   	 dispatch.forward(request, response);
		
	}

}
