package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.dbutility.OracleConnection;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head></head>");
		out.println("<body>");
		out.println("<center>");
		out.println("<h1>UPDATE EMPLOYEE</h1><br>");
		out.println("<form action=\"UpdateEmpServlet\" method=\"post\">");
		try{
			
			 
			Connection conn = OracleConnection.getConnection();
		     System.out.println(conn);
			Statement stmt=conn.createStatement();
			ResultSet rs=stmt.executeQuery("select * from emp");
			out.println("<h1>Select the empid to update</h1>");
			out.println("<h1>enter 0 if u dont want to update</h1>");
			out.println("<select name=\"empid\">");
			while(rs.next())
			{
		
		out.println("<option value="+rs.getString(1)+">"+rs.getString(1)+"</option>");
			}
			out.println("</select>");
			out.println("EmployeeName<input type=\"text\" name=\"empname\"><br>");
			out.println("Password<input type=\"password\" name=\"emppass\"><br>");
			out.println("Salary<input type=\"text\" name=\"empsal\"><br>");
			out.println("DepId<input type=\"text\" name=\"empdepid\"><br>");
			out.println("<input type=\"submit\" value=\"submit\">");
			out.println("<input type=\"reset\" value=\"reset\">");
			out.println("</form>");
			out.println("</center>");
			out.println("</body>");
			out.println("</html>");
		
	}

		catch(Exception e){out.println(e);}

	}	
	
}
