package com.virtusa.employeemgmt.exception;

public class InvalidExistIdException extends Exception {
	private String errorMessage;

	public InvalidExistIdException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
