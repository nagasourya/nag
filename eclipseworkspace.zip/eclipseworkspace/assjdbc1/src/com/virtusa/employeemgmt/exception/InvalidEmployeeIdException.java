package com.virtusa.employeemgmt.exception;

public class InvalidEmployeeIdException extends Exception {
	private String errorMessage;

	public InvalidEmployeeIdException(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
