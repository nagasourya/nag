package com.virtusa.employeemgmt.service;

import java.sql.SQLException;

import com.virtusa.employeemgmt.exception.InvalidEmployeeIdException;
import com.virtusa.employeemgmt.exception.InvalidExistIdException;

public interface EmployeeService {
	public void createEmployee() throws InvalidExistIdException, SQLException;

	public void readEmployee() throws InvalidEmployeeIdException, SQLException;

}
