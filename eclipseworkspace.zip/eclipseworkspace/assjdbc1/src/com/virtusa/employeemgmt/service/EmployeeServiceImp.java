package com.virtusa.employeemgmt.service;

import com.virtusa.employeemgmt.dbutility.OracleConnection;
import com.virtusa.employeemgmt.exception.InvalidEmployeeIdException;
import com.virtusa.employeemgmt.exception.InvalidExistIdException;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class EmployeeServiceImp implements EmployeeService {

	@Override
	public void createEmployee() throws SQLException, InvalidExistIdException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the empcode");
		int empcode = sc.nextInt();
		System.out.println("enter the empname");
		String empname = sc.next();
		System.out.println("Enter the salary");
		double sal = sc.nextDouble();
		try {
			Connection con;

			con = new OracleConnection().getConnection();

			Statement st = con.createStatement();
			int rs = st.executeUpdate("insert into employees values(" + empcode
					+ ",'" + empname + "'," + sal + ")");
			System.out.println("Num of rows " + rs);
		} catch (SQLException ie) {
			throw new InvalidExistIdException("Already Existing");
		}

	}

	@Override
	public void readEmployee() throws InvalidEmployeeIdException, SQLException {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the empcode");
		int empcode = sc.nextInt();

		Connection con = new OracleConnection().getConnection();

		Statement st = con.createStatement();
		ResultSet rs = st
				.executeQuery("Select * from Employees where employeenumber="
						+ empcode + " ");
		if (rs.next()) {
			System.out.println("" + rs.getInt(1) + rs.getString(2)
					+ rs.getInt(3));
		} else

		{
			throw new InvalidEmployeeIdException("Employee id not available");
		}
	}

}
