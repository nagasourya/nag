package com.virtusa.employeemgmt.client;

import java.sql.SQLException;
import java.util.Scanner;

import com.virtusa.employeemgmt.exception.InvalidEmployeeIdException;
import com.virtusa.employeemgmt.exception.InvalidExistIdException;
import com.virtusa.employeemgmt.service.EmployeeServiceImp;

public class EmployeeMain {

	public static void main(String[] args) throws InvalidExistIdException,
			InvalidEmployeeIdException, SQLException {
		EmployeeServiceImp esi = new EmployeeServiceImp();
		Scanner sc = new Scanner(System.in);
		do {
			System.out
					.println("Enter the option 1.creating employee 2.reading employee ");
			int opt = sc.nextInt();
			switch (opt) {

			case 1:
				try {
					esi.createEmployee();
					break;
				} catch (InvalidExistIdException ie) {
					System.out.println(ie.getErrorMessage());
				}

			case 2:
				try {
					esi.readEmployee();
					break;
				} catch (InvalidEmployeeIdException ie) {
					System.out.println(ie.getErrorMessage());
				}

			}

		} while (true);

	}

}
