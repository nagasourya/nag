package com.virtusa.employeemgmt.model;

public class Employee {
	private int empCode;
	private String empName;
	private double Salary;

	public Employee(int empCode, String empName, double salary) {
		super();
		this.empCode = empCode;
		this.empName = empName;
		Salary = salary;
	}

	public int getEmpCode() {
		return empCode;
	}

	public void setEmpCode(int empCode) {
		this.empCode = empCode;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public double getSalary() {
		return Salary;
	}

	public void setSalary(double salary) {
		Salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [empCode=" + empCode + ", empName=" + empName
				+ ", Salary=" + Salary + "]";
	}
}
