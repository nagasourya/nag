
public class Maine {

	public static void main(String[] args) {

		Employee e=new Employee();
		e.setEmpid(1);
		e.setEmpname("sravani");
		e.setDesignation("associate");
		e.setSalary(900.0);
		e.adr=new Address();
		e.adr.setCity("vizag");
		e.adr.setStreetname("dwarkanagar");
		e.adr.setZipcode(530016);
		System.out.println(e.getEmpid());
		System.out.println(e.getEmpname());
		System.out.println(e.getDesignation());
		System.out.println(e.getSalary());
		System.out.println(e.adr.getCity());
		System.out.println(e.adr.getStreetname());
		System.out.println(e.adr.getZipcode());
		
		

	}

}
