function loginValidation()
{
	var empname=document.getElementById("empname").value;
	 if(document.getElementById("empid").value.length>=4)
	 {
	 alert('The empid must be only with length 3');
       return false;

	 }
 var empid=parseInt(document.getElementById("empid").value);	
 if(isNaN(empid))
	 {
	  alert('The empid must be a number');
	return false; 
	}
 if(empname.length<6)
 {
   alert('The Employee length should be greater than 6');
   return false;
 }
if(empname==" " ||empname==null)
 {
   alert('Enter a valid username');
   return false;
 }
}