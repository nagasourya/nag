package com.virtusa.model;

public interface BankOpt {
	public void deposit(String acc, int amt) throws InvalidAccountNumber;

	public void withdraw(String acc, int amt)
			throws InsufficientBalanceException;

	public void showBal(String acc) throws InvalidAccountNumber;

}
