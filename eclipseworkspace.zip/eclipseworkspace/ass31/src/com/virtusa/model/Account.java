package com.virtusa.model;

import java.util.Scanner;

import com.virtusa.model.BankOpt;

public class Account {
	public static void main(String args[]) {

		AccOpt ac = new AccOpt();
		Scanner sc = new Scanner(System.in);
		System.out
				.println("enter the options 1.Deposit 2.Withdraw 3.show Balance");
		int opt = sc.nextInt();
		String acc = "12341258";
		try {
			switch (opt) {
			case 1:
				System.out.println("Enter the amount");
				int amt = sc.nextInt();

				ac.deposit(acc, amt);
				break;
			case 2:
				System.out.println("Enter the amount");
				int amt1 = sc.nextInt();
				ac.withdraw(acc, amt1);
				break;
			case 3:
				System.out.println("Account Details");
				ac.showBal(acc);
				break;
			default:
				System.out.println();

			}
		} catch (InvalidAccountNumber ae) {
			System.out.println(ae);
		} catch (InsufficientBalanceException a1) {
			System.out.println(a1);
		}
	}
}