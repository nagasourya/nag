package com.virtusa.model;

import java.lang.*;
import java.util.Scanner;

import com.virtusa.model.BankOpt;
import com.virtusa.model.InvalidAccountNumber;

public class AccOpt implements BankOpt {

	int currentbal = 5000;

	public void deposit(String acc, int am) throws InvalidAccountNumber {
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Accont no");
		String a = sc.nextLine();
		if (acc.equals(a)) {
			currentbal = currentbal + am;
			System.out.println(currentbal);
		} else {
			throw new InvalidAccountNumber("ACCOUNT NUM IS NOT VALID");
		}

	}

	public void withdraw(String acc, int amt)
			throws InsufficientBalanceException {

		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Accont no");
		String a = sc.nextLine();
		if (acc.equals(a)) {
			currentbal = currentbal - amt;
			System.out.println(currentbal);
		} else {
			throw new InsufficientBalanceException("no balance");
		}
	}

	public void showBal(String acc) throws InvalidAccountNumber {

		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Accont no");
		String a = sc.nextLine();
		if (acc.equals(a)) {
			System.out.println(currentbal);
		} else {
			throw new InvalidAccountNumber("ACCOUNT NUM IS NOT VALID");
		}
	}

}
