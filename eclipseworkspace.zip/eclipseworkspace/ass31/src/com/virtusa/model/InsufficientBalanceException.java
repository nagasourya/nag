package com.virtusa.model;

public class InsufficientBalanceException extends Exception {
	private String errorMessage;

	public InsufficientBalanceException(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
