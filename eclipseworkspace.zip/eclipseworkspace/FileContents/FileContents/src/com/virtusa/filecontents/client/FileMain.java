package com.virtusa.filecontents.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class FileMain {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		try{
			System.out.println("�nter file name");
		Scanner sn=new Scanner(System.in);
		String filename=sn.nextLine();
		
		File f=new File(filename);
		int ch;
		if(f.exists())
		{
			FileInputStream fis=new FileInputStream(f);
			while((ch=fis.read())!=-1)
	         {
	          
	 
	            System.out.write(ch);
	          }
			fis.close();
		}
		else
			System.out.println("File does not exists");
		}
		catch(Exception e){}
	}


	}

