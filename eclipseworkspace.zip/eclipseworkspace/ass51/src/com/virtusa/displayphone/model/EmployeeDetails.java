package com.virtusa.displayphone.model;

public class EmployeeDetails {
	private String empName;
	private String empPhn;

	public EmployeeDetails(String empName, String empPhn) {
		super();
		this.empName = empName;
		this.empPhn = empPhn;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empName=" + empName + ", empPhn=" + empPhn
				+ "]";
	}

}
