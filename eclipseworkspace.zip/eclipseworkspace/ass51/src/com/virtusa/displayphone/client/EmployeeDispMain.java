package com.virtusa.displayphone.client;

import java.util.Iterator;
import java.util.LinkedList;

import com.virtusa.displayphone.model.EmployeeDetails;

public class EmployeeDispMain {

	public static void main(String[] args) {
		LinkedList<EmployeeDetails> ll = new LinkedList<EmployeeDetails>();
		ll.add(new EmployeeDetails("Sravanai", "9703993904"));
		ll.add(new EmployeeDetails("Swapnika", "9966965710"));
		ll.add(new EmployeeDetails("Aparna", "9848969234"));
		ll.add(new EmployeeDetails("Swarna", "8899745234"));
		ll.add(new EmployeeDetails("Leela", "77957989423"));
		Iterator<EmployeeDetails> ir = ll.iterator();
		while (ir.hasNext()) {
			System.out.println(ir.next());
		}
	}

}
