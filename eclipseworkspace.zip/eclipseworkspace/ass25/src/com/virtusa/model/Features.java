package com.virtusa.model;

public interface Features {
	public void noOfLegs();

	public void eyeColor();

}
