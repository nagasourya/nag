package com.virtusa.model;

public abstract class Animal implements Features {
	public void noOfLegs() {
		System.out.println("the no of legs is 4");
	}

	public void eyeColor() {
		System.out.println("The eye color is black or blue");
	}

	public abstract void roaringStyle();

}
