package com.virtusa.model;

public class Cat {
	public void eyeColor() {

		System.out.println("The color is Black");
	}

	public void roaringStyle() {
		System.out.println("The Style Meow-Meow");

	}

}
