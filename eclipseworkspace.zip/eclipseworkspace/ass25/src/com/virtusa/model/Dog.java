package com.virtusa.model;

public class Dog extends Animal {

	public void eyeColor() {

		System.out.println("The color is Blue");
	}

	public void roaringStyle() {
		System.out.println("The Style Bow-Bow");

	}

}
