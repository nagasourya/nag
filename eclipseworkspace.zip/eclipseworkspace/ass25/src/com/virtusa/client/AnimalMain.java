package com.virtusa.client;

import com.virtusa.model.Cat;
import com.virtusa.model.Dog;

public class AnimalMain {
	public static void main(String args[]) {
		Dog d = new Dog();
		Cat c = new Cat();
		d.eyeColor();
		d.roaringStyle();
		c.eyeColor();
		c.roaringStyle();

	}

}
