import java.util.Scanner;

public class Details {
	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);
		System.out.println("enter uname");

		String uname = s.nextLine();
		System.out.println("enter pwd");
		String pwd = s.nextLine();

		Validation v = new Validation();

		if (v.testUser(uname) && v.testPwd(pwd)) {
			System.out.println("hello" + uname);
		} else {
			System.out.println("not valid");
		}

	}

}
