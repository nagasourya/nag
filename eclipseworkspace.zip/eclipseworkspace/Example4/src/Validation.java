
public class Validation {

	

	
	public boolean testUser(String user)
	{
		int length=user.length();
		boolean lenuse=(length>5);
 		if(user.charAt(0)!=' ' && user.charAt(length-1)!=' '&&lenuse)
		{
			System.out.println("username is valid");

			return true;

		}
		System.out.println("username is not valid");
 		return false;
				
	}
	public boolean testPwd(String pd)
	{
		int lengt=pd.length();
	
		boolean len=(lengt>=6 && lengt<12);
		if(pd.charAt(0)!=' ' && (pd.charAt(lengt-1))!=' ')
			if(len)
			{
				System.out.println("Password is valid");
				return true;
			}
		return false;
				
	}

}
