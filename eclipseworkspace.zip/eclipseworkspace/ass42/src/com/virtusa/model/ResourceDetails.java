package com.virtusa.model;

public class ResourceDetails {
	public String resourseId;
	public String resourseName;
	public String hireDate;
	public String position;
	public String department;
	public String Compensation;

	public ResourceDetails(String resourseId, String resourseName,
			String hireDate, String position, String department,
			String compensation) {

		this.resourseId = resourseId;
		this.resourseName = resourseName;
		this.hireDate = hireDate;
		this.position = position;
		this.department = department;
		Compensation = compensation;
	}

	@Override
	public String toString() {
		return "ResourceDetails [resourseId=" + resourseId + ", resourseName="
				+ resourseName + ", hireDate=" + hireDate + ", position="
				+ position + ", department=" + department + ", Compensation="
				+ Compensation + "]";
	}

	public String getResourseName() {
		return resourseName;
	}

	public void setResourseName(String resourseName) {
		this.resourseName = resourseName;
	}

}
