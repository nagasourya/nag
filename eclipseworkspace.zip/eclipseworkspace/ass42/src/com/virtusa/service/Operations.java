package com.virtusa.service;

import java.util.Scanner;
import java.util.TreeSet;

import com.virtusa.model.ResourceDetails;

public class Operations {
	Scanner s = new Scanner(System.in);
	TreeSet<ResourceDetails> ts = new TreeSet<ResourceDetails>(new Comp());

	public void addResource() {

		System.out.println("Enter the ResourceId");
		String ri = s.nextLine();
		System.out.println("Enter the ResourceName");
		String rn = s.nextLine();
		System.out.println("Enter the Hire date");
		String hd = s.nextLine();
		System.out.println("Enter the Position");
		String p = s.nextLine();
		System.out.println("Enter the Department");
		String d = s.nextLine();
		System.out.println("Enter the Compensation");
		String c = s.nextLine();
		ts.add(new ResourceDetails(ri, rn, hd, p, d, c));

	}

	public void removeResource() {

		System.out.println("Enter the ResourceId");
		String ri = s.nextLine();
		System.out.println("Enter the ResourceName");
		String rn = s.nextLine();
		System.out.println("Enter the Hire date");
		String hd = s.nextLine();
		System.out.println("Enter the Position");
		String p = s.nextLine();
		System.out.println("Enter the Department");
		String d = s.nextLine();
		System.out.println("Enter the Compensation");
		String c = s.nextLine();
		ts.remove(new ResourceDetails(ri, rn, hd, p, d, c));

	}

	public void display() {
		System.out.println(ts);
	}

}
