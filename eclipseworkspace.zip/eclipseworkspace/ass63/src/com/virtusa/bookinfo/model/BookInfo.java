package com.virtusa.bookinfo.model;

import java.io.Serializable;

public class BookInfo implements Serializable {
	private String bookTitle;
	private String author;
	private int price;

	public BookInfo(String bookTitle, String author, int price) {
		super();
		this.bookTitle = bookTitle;
		this.author = author;
		this.price = price;
	}

	@Override
	public String toString() {
		return "BookInfo [bookTitle=" + bookTitle + ", author=" + author
				+ ", price=" + price + "]";
	}
}
