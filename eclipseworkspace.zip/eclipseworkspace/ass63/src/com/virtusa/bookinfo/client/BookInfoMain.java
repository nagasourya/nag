package com.virtusa.bookinfo.client;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.virtusa.bookinfo.model.BookInfo;

public class BookInfoMain {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		BookInfo b1 = new BookInfo("java", "herbert", 700);
		BookInfo b2 = new BookInfo("c", "Balaguruswamy", 1100);
		FileOutputStream fos = new FileOutputStream(
				"C:\\Users\\sravaniv@virtusa.com\\Desktop\\bdetails.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(b1);
		oos.writeObject(b2);
		FileInputStream fis = new FileInputStream(
				"C:\\Users\\sravaniv@virtusa.com\\Desktop\\bdetails.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object obj = ois.readObject();
		Object obj1 = ois.readObject();
		System.out.println("The book Details");
		System.out.println((BookInfo) obj);
		System.out.println((BookInfo) obj1);

	}

}
