package com.virtusa.hiber.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.virtusa.hiber.model.Contract_Employee;
import com.virtusa.hiber.model.Employee;
import com.virtusa.hiber.model.Regular_Employee;

public class StoreData {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure("hibernate.cfg.xml").buildSessionFactory().openSession();  
	      
		Transaction t=session.beginTransaction();
		 Employee e=new Employee();
	       e.setId(101);
	       e.setName("Sravani");
	       
	       Regular_Employee re= new Regular_Employee();
	       re.setId(102);
	       re.setName("aparna");
	       re.setBonus(1000);
	       re.setSalary(15264);
	       
	       Contract_Employee ce=new Contract_Employee();
	       ce.setId(103);
	       ce.setName("harika");
	       ce.setPayperhour(1000);
	       ce.setContractduration("6 months");
	       
	       
	       session.persist(e);
	       session.persist(re);
	       session.persist(ce);
	       t.commit();
	       session.close();
	       System.out.println("Successfully done!!!!!!!!!");
		

	}

}
