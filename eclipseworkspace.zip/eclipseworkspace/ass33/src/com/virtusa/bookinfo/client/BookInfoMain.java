package com.virtusa.bookinfo.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


import com.virtusa.bookinfo.model.BooksInfo;

public class BookInfoMain {

	public static void main(String[] args) throws IOException,ClassNotFoundException {
		BooksInfo b1=new BooksInfo("Complete Reference","herbert",500);
		BooksInfo b2=new BooksInfo("first head java","Thomas",900);
		BooksInfo b3=new BooksInfo("c","Bala Guru Swamy",800);
		BooksInfo b4=new BooksInfo("Physics","hc verma",700);
		FileOutputStream fos1=new FileOutputStream("C:\\Users\\sravaniv@virtusa.com\\Desktop\\books.txt");
		ObjectOutputStream oos1=new ObjectOutputStream(fos1);
        oos1.writeObject(b1);
        oos1.writeObject(b2);
        oos1.writeObject(b3);
        oos1.writeObject(b4);
        FileInputStream fis1=new FileInputStream("C:\\Users\\sravaniv@virtusa.com\\Desktop\\books.txt");
		ObjectInputStream ois1=new ObjectInputStream(fis1);
        Object obj1=ois1.readObject();
        Object obj2=ois1.readObject();
        Object obj3=ois1.readObject();
        Object obj4=ois1.readObject();
        System.out.println((BooksInfo)obj1);
        System.out.println((BooksInfo)obj2);
        System.out.println((BooksInfo)obj3);
        System.out.println((BooksInfo)obj4);
	}

}
