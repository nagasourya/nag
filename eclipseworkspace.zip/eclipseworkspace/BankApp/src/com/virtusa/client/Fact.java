package com.virtusa.client;

public class Fact {

	/**
	 * @param args
	 */
		// TODO Auto-generated method stub
	int x,x1=1;
	  
	   public Fact (int n)
	   {
		 x=n;
	   }
		public void facto()
		{
			
			for(int i=1;i<=x;i++)
			{
			x1=x1*i;

			System.out.println("fact is" +x1);
			
			 
			}
		
			
			
		}

	}


