package com.virtusa.client;

import javax.swing.JOptionPane;

public class FactoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=JOptionPane.showInputDialog("Enter the value");
		int n=Integer.parseInt(s);
		Fact f= new Fact(n);
		f.facto();
		

	}

}
