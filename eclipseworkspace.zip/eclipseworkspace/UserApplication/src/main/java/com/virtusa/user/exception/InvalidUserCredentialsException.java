package com.virtusa.user.exception;

/**
 * 
 * @author PADARBINDAS
 * 
 */
public class InvalidUserCredentialsException extends Exception {
	private String errorMessage;

	/**
	 * @default serialVersionUID is used
	 */
	private static final long serialVersionUID = 1L;

	public InvalidUserCredentialsException(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorMessage() {
		return errorMessage;
	}

}
