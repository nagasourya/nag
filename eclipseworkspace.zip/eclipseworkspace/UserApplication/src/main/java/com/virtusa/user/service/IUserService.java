/**
 * 
 */
package com.virtusa.user.service;

import java.util.List;

import com.virtusa.user.exception.InvalidUserCredentialsException;

/**
 * @author PADARBINDAS
 *
 */
public interface IUserService {
   void userLogin(String username,String password) 
   throws InvalidUserCredentialsException;
   /* showAllUserNames() will return all user names */
   List<String> showAllUserNames();
   
}
