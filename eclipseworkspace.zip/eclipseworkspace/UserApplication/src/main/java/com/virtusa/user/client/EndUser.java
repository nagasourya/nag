package com.virtusa.user.client;

import java.util.List;
import java.util.Scanner;

import com.virtusa.user.exception.InvalidUserCredentialsException;
import com.virtusa.user.service.IUserService;
import com.virtusa.user.service.impl.UserServiceImpl;

public class EndUser {
	public static void main(String[] args) {
	/* Dynamic Polymorphism,
	 * 1 Reference can point to multiple objects */	
		/* Instantiate UserServiceImpl object */
	IUserService userService = 
			new UserServiceImpl();
	/* Accept Scanner Input for username and password*/
	Scanner scanner = new Scanner(System.in);
	System.out.println("Enter User name:");
	String username = scanner.next();
	System.out.println("Enter User password:");
	String password = scanner.next();
	try{
		/* invoke the business method
		 * of user interface */
	userService.userLogin(username, password);
	}
	catch(InvalidUserCredentialsException userException){
		System.err.println(userException.getErrorMessage());
	}
	finally{
		// must close to avoid memory leak
		scanner.close();
	}
   /* Invoke showAllUserNames() method */
	List<String> users = 
			userService.showAllUserNames();
	if (!(users.isEmpty())){
	System.out.println("List of Users\n");
	/* for each loop to traverse the array list */
	for (String user:users)
		System.out.println(user);
	}
	
}
}