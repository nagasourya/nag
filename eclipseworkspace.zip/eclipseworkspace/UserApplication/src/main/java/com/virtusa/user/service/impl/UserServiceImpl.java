package com.virtusa.user.service.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.virtusa.user.exception.InvalidUserCredentialsException;
import com.virtusa.user.service.IUserService;

public class UserServiceImpl implements IUserService {

	public void userLogin(String username, String password)
			throws InvalidUserCredentialsException {
		if (("Virtusa").equalsIgnoreCase(username)
		&& ("Virtusa#123").equalsIgnoreCase(password))
			System.out.println("Hello ,"+username+ "Login successful!");
		else
			throw new InvalidUserCredentialsException("Invalid Credentials entered,try again");

	}

	public List<String> showAllUserNames() {
    /* Array List instance referred by List reference */
		List<String> userList = 
				new ArrayList<String>();
		Scanner scanner = null;	
		/* Read user names from a text file */
		try {
			scanner = 
				new Scanner(new File("userData.txt"));
			/* add the file data into array list */
			/* check whether scanner has refer to next element
			 * in a file, if so, continue the loop */
			while (scanner.hasNextLine()){
			/* add the next element to array list */
				userList.add(scanner.nextLine());
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			scanner.close();
		}
		/* return the userList */
		return userList;
	}

}
