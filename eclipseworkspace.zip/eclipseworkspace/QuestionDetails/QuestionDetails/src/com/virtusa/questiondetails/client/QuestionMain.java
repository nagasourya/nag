package com.virtusa.questiondetails.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.virtusa.questiondetails.model.QuestionBank;

public class QuestionMain {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ArrayList<QuestionBank> arr=new ArrayList<QuestionBank>();
		arr.add(new QuestionBank("java", "what is full form of oops", "pavan"));
		arr.add(new QuestionBank("java", "what is full form of awt", "pavan"));
		arr.add(new QuestionBank("php", "what is extension of php", "pavan"));
		FileOutputStream fos=new FileOutputStream("c:\\users\\pavan\\Desktop\\text4.ser");
		ObjectOutputStream oos=new ObjectOutputStream(fos);
        oos.writeObject(arr);
        FileInputStream fis=new FileInputStream("c:\\users\\pavan\\Desktop\\text4.ser");
		ObjectInputStream ois=new ObjectInputStream(fis);
		 Object obj=ois.readObject();
		 ArrayList<QuestionBank> arr1=(ArrayList<QuestionBank>)obj;
		 for(QuestionBank ques:arr1)
		 System.out.println("\n"+ques);
		 }

}
