package com.virtusa.questiondetails.model;

import java.io.Serializable;

public class QuestionBank implements Serializable {

	@Override
	public String toString() {
		return "QuestionBank [questionTitle=" + questionTitle + ", question="
				+ question + ", createdBy=" + createdBy + "]";
	}
	private String questionTitle;
	private String question;
	private String createdBy;
	public String getQuestionTitle() {
		return questionTitle;
	}
	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public QuestionBank(String questionTitle, String question, String createdBy) {
		super();
		this.questionTitle = questionTitle;
		this.question = question;
		this.createdBy = createdBy;
	}
	
}
