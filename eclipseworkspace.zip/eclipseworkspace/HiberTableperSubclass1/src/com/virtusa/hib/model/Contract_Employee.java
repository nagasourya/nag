package com.virtusa.hib.model;

public class Contract_Employee extends Employee {
	private float payperhour;
	public float getPayperhour() {
		return payperhour;
	}
	public void setPayperhour(float payperhour) {
		this.payperhour = payperhour;
	}
	public String getContractduration() {
		return contractduration;
	}
	public void setContractduration(String contractduration) {
		this.contractduration = contractduration;
	}
	private String contractduration;
}
