package com.virtusa.hiber.client;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.virtusa.hib.model.Contract_Employee;
import com.virtusa.hib.model.Employee;
import com.virtusa.hib.model.Regular_Employee;



public class StoreData {
	public static void main(String[] args) {
	       Configuration cfg=new Configuration();
	       cfg.configure("hibernate.cfg.xml");
	       SessionFactory fac=cfg.buildSessionFactory();
	       Session session=fac.openSession();
	       Transaction t=session.beginTransaction();
	       
	       Employee e=new Employee();
	       e.setId(101);
	       e.setName("Sravani");
	       
	       Regular_Employee re= new Regular_Employee();
	       re.setId(102);
	       re.setName("aparna");
	       re.setBonus(1000);
	       re.setSalary(15264);
	       
	       Contract_Employee ce=new Contract_Employee();
	       ce.setId(103);
	       ce.setName("harika");
	       ce.setPayperhour(1000);
	       ce.setContractduration("6 months");
	       
	       
	       session.persist(e);
	       session.persist(re);
	       session.persist(ce);
	       t.commit();
	       session.close();
	       System.out.println("Successfully done!!!!!!!!!");
	       
	       

		}

}
