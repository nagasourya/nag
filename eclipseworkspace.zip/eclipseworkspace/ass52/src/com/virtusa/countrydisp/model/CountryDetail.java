package com.virtusa.countrydisp.model;

public class CountryDetail {
	private String conName;
	private String conCapName;

	public CountryDetail(String conName, String conCapName) {
		super();
		this.conName = conName;
		this.conCapName = conCapName;
	}

	@Override
	public String toString() {
		return "CountryDetail [conName=" + conName + ", conCapName="
				+ conCapName + "]";
	}

	public String getConName() {
		return conName;
	}

	public void setConName(String conName) {
		this.conName = conName;
	}

	public String getConCapName() {
		return conCapName;
	}

	public void setConCapName(String conCapName) {
		this.conCapName = conCapName;
	}

}
