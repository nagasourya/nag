package com.virtusa.countrydisp.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import com.virtusa.countrydisp.model.CountryDetail;

public class CountryMain {

	public static void main(String[] args) {
		HashMap<String, CountryDetail> hm = new HashMap();
		hm.put("Afghanistan", new CountryDetail("Afghanistan", "Kabul"));
		hm.put("Bhutan", new CountryDetail("Bhutan", "Thimpu"));
		hm.put("Denmark", new CountryDetail("Denmark", "Copenhagen"));
		hm.put("India", new CountryDetail("India", "Delhi"));
		List<CountryDetail> clist = new ArrayList<CountryDetail>(hm.values());

		Collections.sort(clist, new Comparator<CountryDetail>() {

			public int compare(CountryDetail c1, CountryDetail c2) {

				return c1.getConCapName().compareTo(c2.getConCapName());
			}
		});

		for (CountryDetail c : clist) {
			System.out.println(c.getConName() + "\t" + c.getConCapName());
		}

		System.out.println(hm);

	}

}
