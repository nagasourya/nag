import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class DataInsertPre {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the empid");
		int empid=sc.nextInt();
		System.out.println("Enter the empname");
		String empname=sc.next();
		System.out.println("Enter the salary");
		int sal=sc.nextInt();
		System.out.println("Enter the age");
		int age=sc.nextInt();
		System.out.println("Enter the adress");
		String add=sc.next();
		Driver d=new oracle.jdbc.OracleDriver();
		DriverManager.registerDriver(d);
		System.out.println("Driver Loaded");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		System.out.println("Connection Established");
		//String q="insert into employee values("+empid+",'"+empname+"',"+sal+","+age+",'"+add+"')";
		String q="insert into employee values(?,?,?,?,?)";	
		PreparedStatement pstmt=con.prepareStatement(q);

			pstmt.setInt(1, empid);
			pstmt.setString(2, empname);
			pstmt.setInt(3, sal);
			pstmt.setInt(4, age);
			pstmt.setString(5,add);
			int rs=pstmt.executeUpdate();
		
		
				System.out.println("Num of rows "+rs);
		
			
			con.close();
			
		
	

	}

}
