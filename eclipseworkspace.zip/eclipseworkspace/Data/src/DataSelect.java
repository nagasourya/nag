import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class DataSelect {

	public static void main(String[] args) throws SQLException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the empid");
		int empid=sc.nextInt();
		Driver d=new oracle.jdbc.OracleDriver();
		DriverManager.registerDriver(d);
		System.out.println("Driver Loaded");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		System.out.println("Connection Established");
			Statement st=con.createStatement();
	ResultSet rs=st.executeQuery("select * from employee where empid="+empid+" ");
	      //  int c=st.executeUpdate("Select count(*) from employee");
		
		     while(rs.next()){
		    
				System.out.println("The row is"+rs.getInt(1)+rs.getString(2)+rs.getInt(3)+rs.getInt(4)+rs.getString(5));
				System.out.println("the total rows");
		     }
		  
			con.close();

	}

}
