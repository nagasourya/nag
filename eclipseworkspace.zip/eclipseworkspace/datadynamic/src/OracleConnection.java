import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;


public class OracleConnection {
	Connection con;
  public static Connection getConnection() throws SQLException
  {
	
	Driver d=new oracle.jdbc.OracleDriver();
	DriverManager.registerDriver(d);
	System.out.println("Driver Loaded");
	Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");

	return con;
	  
  }
}
