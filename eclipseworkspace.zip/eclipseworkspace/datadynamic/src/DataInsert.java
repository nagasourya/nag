import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class DataInsert {

	public static void main(String[] args) throws SQLException {
		
OracleConnection oc=new OracleConnection();
Connection con= oc.getConnection();
Scanner sc=new Scanner(System.in);
System.out.println("Enter the empid");
int empid=sc.nextInt();
System.out.println("Enter the empname");
String empname=sc.next();
System.out.println("Enter the salary");
int sal=sc.nextInt();
System.out.println("Enter the age");
int age=sc.nextInt();
System.out.println("Enter the adress");
String add=sc.next();

Statement st=con.createStatement();
int rs=st.executeUpdate("insert into employee values("+empid+",'"+empname+"',"+sal+","+age+",'"+add+"')");
System.out.println("Num of rows "+rs);
con.close();



	}

}
