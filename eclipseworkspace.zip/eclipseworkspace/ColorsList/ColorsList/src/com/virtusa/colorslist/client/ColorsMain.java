package com.virtusa.colorslist.client;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;


public class ColorsMain {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		ArrayList<String> colors=new ArrayList<String>();
		colors.add("red");
		colors.add("blue");
		colors.add("green");
		colors.add("violet");
		colors.add("white");
		colors.add("yellow");
		colors.add("brown");
		//System.out.println(colors);
	

		FileWriter fw=new FileWriter("text2.txt");
		
		for(String c:colors)
		fw.write("\n"+c);
         fw.close();
         String str;
         FileReader fr=new FileReader("text2.txt"); 
         BufferedReader bf=new BufferedReader(fr);
         while((str=bf.readLine())!=null)
         {
        	 System.out.println(str);
         }
        	 
        
        	
         
	}

}
