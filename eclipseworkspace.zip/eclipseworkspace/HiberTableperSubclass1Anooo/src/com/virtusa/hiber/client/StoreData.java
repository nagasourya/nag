package com.virtusa.hiber.client;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import com.virtusa.hiber.model.Contract_Employee;
import com.virtusa.hiber.model.Employee;
import com.virtusa.hiber.model.Regular_Employee;

public class StoreData {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AnnotationConfiguration cfg=new AnnotationConfiguration();  
	    Session session=cfg.configure("hibernate.cfg.xml").buildSessionFactory().openSession();  
	      
	    Transaction t=session.beginTransaction();  
	      
	    Employee e1=new Employee();  
	    e1.setId(101);
	    e1.setName("sonoo1");  
	      
	    Regular_Employee e2=new Regular_Employee(); 
	    e2.setId(102);
	    e2.setName("Vivek Kumar1");  
	    e2.setSalary(500001);  
	    e2.setBonus(51);  
	      
	    Contract_Employee e3=new Contract_Employee();  
	    e3.setId(103);
	    e3.setName("Arjun Kumar1");  
	    e3.setPayperhour(10001);  
	    e3.setContractduration("15 hours1");  
	      
	    session.persist(e1);  
	    session.persist(e2);  
	    session.persist(e3);  
	      
	    t.commit();  
	    session.close();  
	    System.out.println("success");  

	}

}
