package com.virtusa.empdetails;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class EmpManip {


	public static void main(String[] args) {
	AnnotationConfiguration acfg=new AnnotationConfiguration();
	acfg.configure("hibernate.cfg.xml");
	SessionFactory fac=acfg.buildSessionFactory();
	Session session=fac.openSession();
	Transaction t=session.beginTransaction();
	Empetail e1=new Empetail();
	e1.setId(101);
	e1.setFirstName("aparna");
	e1.setLastName("vaddi");
	session.persist(e1);
	t.commit();
	session.close();
	System.out.println("Success");
	

	}

}

