package com.virtusa.hib.login;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LoginDao {

	
		public static int register(User u){  
			 int i=0;  
			 Session session=new Configuration().  
			 configure().buildSessionFactory().openSession();  
		          
		Transaction t=session.beginTransaction();  
	  
		                 
	   i=(Integer)session.save(u);  
	 t.commit();  
		session.close();  
       return i;  
	
		
			  
	}

}
	


