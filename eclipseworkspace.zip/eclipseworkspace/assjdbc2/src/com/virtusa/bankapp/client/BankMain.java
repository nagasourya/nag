package com.virtusa.bankapp.client;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.virtusa.bankapp.exceptions.AlreadyExistingAccountNumberExceptions;
import com.virtusa.bankapp.exceptions.InsufficientAmoutExceptions;
import com.virtusa.bankapp.exceptions.InvalidAccountNumberExceptions;
import com.virtusa.bankapp.service.BankServiceImpl;

public class BankMain {
	private static Logger log = Logger.getLogger(BankMain.class);

	public static void main(String[] args) throws SQLException,
			InsufficientAmoutExceptions, InvalidAccountNumberExceptions,
			AlreadyExistingAccountNumberExceptions {
		log.setLevel(Level.TRACE);
		BankServiceImpl bs = new BankServiceImpl();
		Scanner sc = new Scanner(System.in);
		try {
			do {
				System.out
						.println("Enter 1.Creating account 2.amount transfer 3.Account Status");
				int opt = sc.nextInt();
				log.info("user selected the option" + new Date().getDate());
				switch (opt) {
				case 1:
					try {
						bs.createAccount();
						log.trace("created");
					} catch (AlreadyExistingAccountNumberExceptions e) {
						log.error(e.getErrorMessage());

					} catch (InvalidAccountNumberExceptions e) {
						log.error(e.getErrorMessage());
					} catch (InsufficientAmoutExceptions e) {
						log.error(e.getErrorMessage());
					}

					break;

				case 2:
					try {
						bs.transferAmmount();
						log.trace("amount transferreed");
						break;
					} catch (InvalidAccountNumberExceptions e) {
						log.error(e.getErrorMessage());
					} catch (InsufficientAmoutExceptions e) {
						log.error(e.getErrorMessage());
					}
				case 3:
					try {
						bs.accountDetails();
						log.trace("Account Details Displayed");
						break;
					} catch (InvalidAccountNumberExceptions ie) {
						log.error(ie.getErrorMessage());
					}
				default:
					log.info("Enter the right option");

				}

			} while (true);

		} catch (NumberFormatException ie) {
			log.error("Enter the valid format ");
		}
	}

}
