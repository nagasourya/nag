package com.virtusa.bankapp.model;

public class AccountDetails {
	private int accountNum;
	private String customerName;
	private double balance;

	public AccountDetails(int accountNum, String customerName, double balance) {

		this.accountNum = accountNum;
		this.customerName = customerName;
		this.balance = balance;
	}

	public int getAccountNum() {
		return accountNum;
	}

	@Override
	public String toString() {
		return "AccountDetails [accountNum=" + accountNum + ", customerName="
				+ customerName + ", balance=" + balance + "]";
	}

	public void setAccountNum(int accountNum) {
		this.accountNum = accountNum;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}
