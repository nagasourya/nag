package com.virtusa.bankapp.exceptions;

public class InsufficientAmoutExceptions extends Exception {
	private String errorMessage;

	public InsufficientAmoutExceptions(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
