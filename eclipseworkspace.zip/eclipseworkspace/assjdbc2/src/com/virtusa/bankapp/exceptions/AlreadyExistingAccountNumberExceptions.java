package com.virtusa.bankapp.exceptions;

public class AlreadyExistingAccountNumberExceptions extends Exception {
	private String errorMessage;

	public AlreadyExistingAccountNumberExceptions(String errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

}
