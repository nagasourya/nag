package com.virtusa.bankapp.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.virtusa.bankapp.client.BankMain;
import com.virtusa.bankapp.dbutility.OracleConnection;
import com.virtusa.bankapp.exceptions.AlreadyExistingAccountNumberExceptions;
import com.virtusa.bankapp.exceptions.InsufficientAmoutExceptions;
import com.virtusa.bankapp.exceptions.InvalidAccountNumberExceptions;

public class BankServiceImpl implements BankService {

	private static Logger log = Logger.getLogger(BankServiceImpl.class);

	Scanner sc = new Scanner(System.in);

	public void createAccount() throws SQLException,
			AlreadyExistingAccountNumberExceptions,
			InvalidAccountNumberExceptions, InsufficientAmoutExceptions {
		log.setLevel(Level.TRACE);
		System.out.println("Enter the Account Number");
		int acno = Integer.parseInt(sc.nextLine());
		log.info("user entered the account number ");
		System.out.println("Enter the account name");
		String accname = sc.nextLine();
		log.info("user entered the account name ");
		System.out.println("Enter the amount to deposit");
		double amount = Double.parseDouble(sc.nextLine());
		log.info("user entered the amount ");
		try {

			Connection con;

			con = new OracleConnection().getConnection();
			log.debug("connection established");
			Statement st = con.createStatement();
			if (acno < 0) {
				throw new InvalidAccountNumberExceptions(
						"Enter a positive account number");
			}
			if (amount < 0) {
				throw new InsufficientAmoutExceptions("Enter the amount > 0");
			}

			int rs = st.executeUpdate("insert into accounts values(" + acno
					+ ",'" + accname + "'," + amount + ")");

			con.close();
			log.debug("connection closed");
		} catch (SQLException ie) {

			throw new AlreadyExistingAccountNumberExceptions("Already Existing");

		}
	}

	public void transferAmmount() throws SQLException,
			InsufficientAmoutExceptions, InvalidAccountNumberExceptions {

		System.out.println("Enter the source account");
		int saccno = sc.nextInt();
		log.info("user entered the source account");
		int tess = tests(saccno);
		if (tess == 1) {
			System.out.println("The Source Account Exists");
		} else {
			throw new InvalidAccountNumberExceptions(
					"Enter the correct source accno");
		}
		System.out.println("Enter the Destination Account");
		int daccno = sc.nextInt();
		log.info("user entered the destination account");
		int tesd = tests(daccno);
		if (tesd == 1) {
			System.out.println("The Destination Account Exists");
		} else {
			throw new InvalidAccountNumberExceptions(
					"Enter the correct Destination accno");
		}

		System.out.println("Enter the amount to transfer");
		double amt = sc.nextDouble();
		log.info("user entered the amount to transfer ");
		double usamt = withdrawSource(saccno, amt);
		Connection con;
		con = new OracleConnection().getConnection();
		log.debug("connection established");
		Statement st = con.createStatement();
		int s = st.executeUpdate("update accounts set amount=" + usamt
				+ " where accno=" + saccno + "");
		// System.out.println("the row updated"+s);
		double udamt = depositDestination(daccno, amt);
		int d = st.executeUpdate("update accounts set amount=" + udamt
				+ " where accno=" + daccno + "");
		// System.out.println("the row updated"+d);
		System.out.println("transactions completed");
		con.close();
		log.debug("connection closed");
	}

	private int tests(int saccno) throws SQLException {
		Connection con;
		con = new OracleConnection().getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * from accounts where accno="
				+ saccno + " ");
		if (rs.next()) {
			if (rs.getInt(1) == saccno && saccno > 0) {
				return 1;
			}

		}
		con.close();
		return 0;

	}

	public double withdrawSource(int acc, double amt) throws SQLException,
			InsufficientAmoutExceptions {
		double sbal = 0;
		Connection con;
		con = new OracleConnection().getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * from accounts where accno="
				+ acc + " ");
		if (rs.next()) {
			double bal = rs.getInt(3);
			if (bal > amt) {
				sbal = bal - amt;

			} else {
				throw new InsufficientAmoutExceptions(
						"enter the bal not exceeding the  accountbal ");
			}
		}
		con.close();
		return sbal;
	}

	public double depositDestination(int acc, double amt) throws SQLException {
		double destbal = 0;
		Connection con;
		con = new OracleConnection().getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * from accounts where accno="
				+ acc + " ");
		if (rs.next()) {
			double bal = rs.getInt(3);
			destbal = bal + amt;

		}
		con.close();
		return destbal;
	}

	@Override
	public void accountDetails() throws SQLException,
			InvalidAccountNumberExceptions {

		System.out.println("Enter the Account Number");
		int acno = sc.nextInt();
		log.info("user entered the account number");
		int tes = tests(acno);
		if (tes == 1) {
			Connection con;
			con = new OracleConnection().getConnection();
			Statement st = con.createStatement();
			log.debug("connection established");
			ResultSet rs = st
					.executeQuery("Select * from accounts where accno=" + acno
							+ " ");
			if (rs.next()) {
				System.out.println("Account Name  " + rs.getString(2)
						+ "Balance " + rs.getDouble(3));
			}
			con.close();
			log.debug("connection closed");
		} else {
			throw new InvalidAccountNumberExceptions(
					"Enter a valid Account Number");
		}

	}

}
