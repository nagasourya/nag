package com.virtusa.bankapp.service;

import java.sql.SQLException;

import com.virtusa.bankapp.exceptions.AlreadyExistingAccountNumberExceptions;
import com.virtusa.bankapp.exceptions.InsufficientAmoutExceptions;
import com.virtusa.bankapp.exceptions.InvalidAccountNumberExceptions;

public interface BankService {
	public void createAccount() throws SQLException,
			AlreadyExistingAccountNumberExceptions,
			InvalidAccountNumberExceptions, InsufficientAmoutExceptions;

	public void transferAmmount() throws SQLException,
			InsufficientAmoutExceptions, InvalidAccountNumberExceptions;

	public void accountDetails() throws SQLException,
			InvalidAccountNumberExceptions;

}