package com.virtusa.questioninfo.client;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import com.virtusa.questioninfo.model.QueBank;

public class QueMain {
	public static void main(String args[]) throws IOException,
			ClassNotFoundException {
		ArrayList<QueBank> ar = new ArrayList<QueBank>();
		ar.add(new QueBank("oracle", "What is SQL?", "sravani"));
		ar.add(new QueBank("java", "what is oops concept", "aparna"));
		ar.add(new QueBank("C", "Is C proceduralprogramming ", "swarna"));
		FileOutputStream fos1 = new FileOutputStream("Questions.ser");
		ObjectOutputStream oos1 = new ObjectOutputStream(fos1);
		oos1.writeObject(ar);
		FileInputStream fis1 = new FileInputStream("Questions.ser");
		ObjectInputStream ois1 = new ObjectInputStream(fis1);
		Object obj = ois1.readObject();
		ArrayList<QueBank> arr1 = (ArrayList<QueBank>) obj;
		for (QueBank ques : arr1)
			System.out.println("\n" + ques);
	}

}
