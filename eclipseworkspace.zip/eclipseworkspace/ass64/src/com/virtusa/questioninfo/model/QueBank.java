package com.virtusa.questioninfo.model;

import java.io.Serializable;

public class QueBank implements Serializable {
	private String queTitle;
	private String question;
	private String createdBy;

	public QueBank(String queTitle, String question, String createdBy) {
		super();
		this.queTitle = queTitle;
		this.question = question;
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "QueBank [queTitle=" + queTitle + ", question=" + question
				+ ", createdBy=" + createdBy + "]";
	}
}
