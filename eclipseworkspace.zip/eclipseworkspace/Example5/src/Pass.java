import javax.swing.JOptionPane;

public class Pass {

	public static void main(String[] args) {
		int s = Integer.parseInt(JOptionPane.showInputDialog("enter salary"));
		double HRA = ((10 * s) / 100);
		double CA = ((5 * s) / 100);
		double PF = ((12 * s) / 100);
		double TAX = ((2 * s) / 100);
		double gsalary = (HRA + CA + s);
		double netsalary = (gsalary - PF - TAX);
		System.out.println("salary" + s + "\nHRA" + HRA + "\nCA" + CA + "\nPF"
				+ PF + "\nTAX" + TAX + "\nGROSS SALARY" + gsalary
				+ "\n NET SALARY" + netsalary);// TODO Auto-generated method
												// stub

	}

}
