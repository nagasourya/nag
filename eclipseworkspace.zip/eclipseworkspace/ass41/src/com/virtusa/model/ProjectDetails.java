package com.virtusa.model;

public class ProjectDetails {

	private String projectId;
	private String projectName;
	private String startDate;
	private String endDate;
	private String budget;
	private String ProjectManName;
	private String BusinessUnit;

	public ProjectDetails(String projectId, String projectName,
			String startDate, String endDate, String budget,
			String projectManName, String businessUnit) {

		this.projectId = projectId;
		this.projectName = projectName;
		this.startDate = startDate;
		this.endDate = endDate;
		this.budget = budget;
		ProjectManName = projectManName;
		BusinessUnit = businessUnit;
	}

	@Override
	public String toString() {
		return "ProjectDetails [projectId=" + projectId + ", projectName="
				+ projectName + ", startDate=" + startDate + ", endDate="
				+ endDate + ", budget=" + budget + ", ProjectManName="
				+ ProjectManName + ", BusinessUnit=" + BusinessUnit + "]";
	}

}
