package com.virtusa.client;

import java.util.ArrayList;

import com.virtusa.model.ProjectDetails;

public class Projects {

	public static void main(String[] args) {
		ArrayList<ProjectDetails> a = new ArrayList<ProjectDetails>();
		a.add(new ProjectDetails("101", "BT", "03-03-15", "01-04-16", "15000",
				"Sravan", "Develop Team"));
		a.add(new ProjectDetails("102", "C++", "04-06-15", "06-06-16", "16700",
				"aparna", "Deploy Team"));
		a.add(new ProjectDetails("101", "BT", "07-04-15", "31-07-16", "24500",
				"Swapnika", "System Team"));
		System.out.println(a);

	}

}
