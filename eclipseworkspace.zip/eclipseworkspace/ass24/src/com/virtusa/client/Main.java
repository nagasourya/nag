package com.virtusa.client;

import com.virtusa.model.First;
import com.virtusa.model.Second;

public class Main {

	public static void main(String[] args) {
		First f = new First();
		Second s = new Second();
		f.one();
		s.one();
		System.out.println("After Run Time Polymorphism");
		f = s;
		f.one();

	}

}
