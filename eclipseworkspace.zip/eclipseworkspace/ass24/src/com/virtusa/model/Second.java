package com.virtusa.model;

public class Second extends First {
	public void one() {
		System.out.println("This is second");
	}
}
