package com.virtusa.model;

public class First {
	public void one() {
		System.out.println("This is one");

	}

}
