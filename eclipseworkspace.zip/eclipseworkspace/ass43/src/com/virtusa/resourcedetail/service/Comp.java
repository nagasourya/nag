package com.virtusa.resourcedetail.service;
import com.virtusa.resourcedetail.model.ResourceDetails;

import java.util.Comparator;



class Comp implements Comparator<ResourceDetails> {

	public int compare(ResourceDetails r1, ResourceDetails r2) {
		return r1.getResourseName().compareTo(r2.getResourseName());
	}
}