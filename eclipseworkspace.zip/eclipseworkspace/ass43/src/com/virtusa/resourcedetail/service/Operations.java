package com.virtusa.resourcedetail.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;

import sun.misc.Compare;

import com.virtusa.resourcedetail.model.ResourceDetails;

public class Operations {
	Scanner s = new Scanner(System.in);
	HashSet<ResourceDetails> hs = new HashSet<ResourceDetails>();

	public void addResource() {

		System.out.println("Enter the ResourceId");
		String ri = s.nextLine();
		System.out.println("Enter the ResourceName");
		String rn = s.nextLine();
		System.out.println("Enter the Hire date");
		String hd = s.nextLine();
		System.out.println("Enter the Position");
		String p = s.nextLine();
		System.out.println("Enter the Department");
		String d = s.nextLine();
		System.out.println("Enter the Compensation");
		String c = s.nextLine();
		hs.add(new ResourceDetails(ri, rn, hd, p, d, c));

	}

	public void removeResource() {
		System.out.println("Enter the resource Id:");
		String rid = s.nextLine();
		Iterator<ResourceDetails> ir = hs.iterator();
		while (ir.hasNext()) {
			ResourceDetails rd = ir.next();
			if (rd.getResourseId().equals(rid)) {
				hs.remove(rd);
			}
		}
		System.out.println(hs);
	}

	public void display() {
		System.out.println(hs);
	}

	public void sort() {

		ArrayList sl = new ArrayList(hs);
		Collections.sort(sl, new Comp());
		System.out.println(sl);
	}

}
