package com.virtusa.resourcedetail.client;

import com.virtusa.resourcedetail.service.Operations;

import java.util.Scanner;
import java.util.TreeSet;

import com.virtusa.resourcedetail.model.ResourceDetails;

public class ResourceAdmin {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		Operations o = new Operations();
		do {
			System.out
					.println("Enter the option 1.ADD 2.Remove 3.Display 4.sorting");
			int opt = sc.nextInt();

			switch (opt) {
			case 1:
				o.addResource();
				break;
			case 2:
				o.removeResource();
				break;
			case 3:
				o.display();
				break;
			case 4:
				o.sort();
				break;

			default:
				System.out.println("Enter the right option");

			}
		} while (true);

	}
}
