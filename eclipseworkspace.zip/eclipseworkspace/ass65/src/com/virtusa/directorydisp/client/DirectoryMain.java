package com.virtusa.directorydisp.client;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class DirectoryMain {

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		System.out.println("�nter directory name");
		String filename = sc.nextLine();
		File directory = new File(filename);
		displayDirContents(directory);

	}

	public static void displayDirContents(File directory) throws IOException {

		File[] fList = directory.listFiles();
		for (File file : fList) {

			System.out.println(file.getCanonicalPath());

		}
	}

}
