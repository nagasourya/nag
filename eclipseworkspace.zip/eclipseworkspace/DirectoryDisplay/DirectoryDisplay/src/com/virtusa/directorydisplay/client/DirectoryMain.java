package com.virtusa.directorydisplay.client;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class DirectoryMain {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		Scanner sn=new Scanner(System.in);
		System.out.println("�nter directory name");
		String filename=sn.nextLine();
		File directory=new File(filename);
		displayDirectoryContents(directory);
		

	}

	public static void displayDirectoryContents(File directory) throws IOException
	{
		
		File[] fList=directory.listFiles();
		for(File file:fList){
			
				System.out.println(file.getCanonicalPath());
			
	}
	}
}
