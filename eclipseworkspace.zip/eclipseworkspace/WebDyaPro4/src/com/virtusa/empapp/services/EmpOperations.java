package com.virtusa.empapp.services;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.empapp.model.DepDetails;
import com.virtusa.empapp.model.EmpDetails;

public interface EmpOperations {
	public int selectEmployee(EmpDetails emp) throws SQLException;
	public int addEmployee(EmpDetails emp) throws SQLException;
	public int delEmployee(EmpDetails emp) throws SQLException;
	public int updateEmployee(EmpDetails emp) throws SQLException;
	public List<EmpDetails> selectAllEmployee() throws SQLException;
	public List<DepDetails> selectAllDep() throws SQLException;

}
