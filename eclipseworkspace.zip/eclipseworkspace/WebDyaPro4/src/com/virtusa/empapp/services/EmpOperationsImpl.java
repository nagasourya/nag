package com.virtusa.empapp.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.empapp.dbutility.OracleConnection;
import com.virtusa.empapp.model.DepDetails;
import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.servlet.*;

public class EmpOperationsImpl implements EmpOperations {
          
	
		int depid=0;

	public int selectEmployee(EmpDetails emp) throws SQLException {
		try{
		Connection con=OracleConnection.getConnection();
		System.out.println(con);
	PreparedStatement pstmt=con.prepareStatement("select * from emp where empid=? and password=? ");
	pstmt.setInt(1,emp.getEmpId());
	pstmt.setString(2,emp.getPassword());
	
		
	ResultSet rs=pstmt.executeQuery();
	if(rs.next())
	{
	depid=rs.getInt(5);
	return depid;
	}}catch(Exception e){System.out.println(e);}
	
		return depid;
	}

	@Override
	public int addEmployee(EmpDetails emp) throws SQLException {
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("insert into emp values("+emp.getEmpId()+",'"+emp.getEmpName()+"','"+emp.getPassword()+"',"+emp.getSalary()+","+emp.getDepId()+")");
		return i;
	}
	@Override
	public int delEmployee(EmpDetails emp) throws SQLException {
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("delete from emp where empid="+emp.getEmpId()+ "");
		return i;
	}

	public int updateEmployee(EmpDetails emp) throws SQLException {
		// TODO Auto-generated method stub
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		int i=stmt.executeUpdate("update emp set empname='"+emp.getEmpName()+"',password='"+emp.getPassword()+"',salary="+emp.getSalary()+",depid="+emp.getDepId()+" where empid="+emp.getEmpId()+ "");
		return i;
	}

	public List<EmpDetails> selectAllEmployee() throws SQLException {
		// TODO Auto-generated method stub
		ArrayList<EmpDetails> arrl=new ArrayList<EmpDetails>();
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from emp");
		while(rs.next())
		{
			EmpDetails emp=new EmpDetails();
			emp.setEmpId(rs.getInt(1));
			emp.setEmpName(rs.getString(2));
			emp.setPassword(rs.getString(3));
			emp.setSalary(rs.getDouble(4));
			emp.setDepId(rs.getInt(5));
			arrl.add(emp);
			
		}
		
		
		return arrl;
	}

	@Override
	public List<DepDetails> selectAllDep() throws SQLException {
		ArrayList<DepDetails> arrl=new ArrayList<DepDetails>();
		Connection con=new OracleConnection().getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from department");
		while(rs.next())
		{
			DepDetails dep=new DepDetails();
			dep.setDepId(rs.getInt(1));
			dep.setDepName(rs.getString(2));
			arrl.add(dep);
		}
		
		return arrl;
	}

}
