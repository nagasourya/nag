package com.virtusa.empapp.model;

public class DepDetails {
	private int depId;
	private String depName;
	public DepDetails(int depId, String depName) {
		super();
		this.depId = depId;
		this.depName = depName;
	}
	public int getDepId() {
		return depId;
	}
	public void setDepId(int depId) {
		this.depId = depId;
	}
	public String getDepName() {
		return depName;
	}
	public DepDetails() {
		super();
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	@Override
	public String toString() {
		return "DepDetails [depId=" + depId + ", depName=" + depName + "]";
	}
	

}
