package com.virtusa.empapp.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.empapp.model.DepDetails;
import com.virtusa.empapp.model.EmpDetails;
import com.virtusa.empapp.services.EmpOperationsImpl;

/**
 * Servlet implementation class Dep
 */
@WebServlet("/Dep")
public class Dep extends HttpServlet {
	
	protected void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
		 List<DepDetails> deplist;
	      EmpOperationsImpl eoi=new EmpOperationsImpl();
	      try {
			deplist=eoi.selectAllDep();
			RequestDispatcher dispatch=request.getRequestDispatcher("Addj.jsp");
		request.setAttribute("deplist",deplist);
	    dispatch.forward(request,response);
	      }
	      catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	

}
