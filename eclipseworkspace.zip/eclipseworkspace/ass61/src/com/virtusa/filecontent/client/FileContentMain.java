package com.virtusa.filecontent.client;

import java.io.File;
import java.io.FileInputStream;
import java.util.Scanner;

public class FileContentMain {

	public static void main(String[] args) {
		try {
			System.out.println("�nter file name");
			Scanner sn = new Scanner(System.in);
			String fname = sn.nextLine();

			File f = new File(fname);
			int ch;
			if (f.exists()) {
				FileInputStream fis = new FileInputStream(f);
				while ((ch = fis.read()) != -1) {

					System.out.write((char) ch);
				}
				fis.close();
			} else
				System.out.println("File does not exists");
		} catch (Exception e) {
		}

	}

}
