package com.virtusa.service;

import com.virtusa.model.Employee;
import com.virtusa.model.Student;

public class Checking {
	public void check(String s,String n,Student obj[])
	{
		for(int i=0;i<2;i++)
		{
			if(obj[i].sid.equals(s) && obj[i].sname.equals(n))
			{
				obj[i].display();
			}
		}
	}
	public void empCheck(String ei,String en,Employee obj1[])
	{
		for(int i=0;i<2;i++)
		{
			if(obj1[i].sid.equals(ei) && obj1[i].sname.equals(en))
			{
				obj1[i].display();
			}
		}
	}
}
