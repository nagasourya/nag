package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.model.Employee;
import com.virtusa.model.Student;
import com.virtusa.service.Checking;

public class Main {

	public static void main(String[] args) {
		Student obj[] = new Student[3];
		Employee obj1[] = new Employee[3];

		for (int i = 0; i < 2; i++) {
			Scanner s1 = new Scanner(System.in);
			System.out.println("Enter student id");
			String si = s1.nextLine();
			System.out.println("Enter student name");
			String sn = s1.nextLine();
			System.out.println("Enter birthdate ");
			String sd = s1.nextLine();
			System.out.println("Enter blood group ");
			String sb = s1.nextLine();
			System.out.println("Enter height");
			String sh = s1.nextLine();
			System.out.println("Enter marks name");
			String sm = s1.nextLine();
			obj[i] = new Student(si, sn, sd, sb, sh, sm);
		}
		Scanner s2 = new Scanner(System.in);
		System.out.println("Enter student exist id");
		String sid = s2.nextLine();
		System.out.println("Enter student exist name");
		String sname = s2.nextLine();
		Checking c = new Checking();
		c.check(sid, sname, obj);
		for (int i = 0; i < 2; i++) {
			Scanner s3 = new Scanner(System.in);
			System.out.println("Enter semployee id");
			String si = s3.nextLine();
			System.out.println("Enter emp name");
			String sn = s3.nextLine();
			System.out.println("Enter birthdate ");
			String sd = s3.nextLine();
			System.out.println("Enter blood group ");
			String sb = s3.nextLine();
			System.out.println("Enter height");
			String sh = s3.nextLine();
			obj1[i] = new Employee(si, sn, sd, sb, sh);
		}
		Scanner s4 = new Scanner(System.in);
		System.out.println("Enter emp exist id");
		String emid = s4.nextLine();
		System.out.println("Enter emp exist name");
		String ename = s4.nextLine();

		c.empCheck(emid, ename, obj1);

	}

}
