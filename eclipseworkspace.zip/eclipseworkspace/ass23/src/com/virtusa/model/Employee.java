package com.virtusa.model;

public class Employee extends Student {

	public Employee(String sid, String sname, String dob, String bloodGroup,
			String height) {
		super(sid, sname, dob, bloodGroup, height);
		// TODO Auto-generated constructor stub
	}

	public void display() {
		System.out.println("the empid is" + sid);
		System.out.println("the empname is" + sname);
		System.out.println("the dob is" + dob);
		System.out.println("the blood group is" + bloodGroup);
		System.out.println("the height is" + height);

	}

}
