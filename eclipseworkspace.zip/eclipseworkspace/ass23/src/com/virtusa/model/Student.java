package com.virtusa.model;

public class Student {

	public String sid;
	public String sname;
	public String dob;
	public String bloodGroup;
	public String height;
	public String marks;

	public Student(String sid, String sname, String dob, String bloodGroup,
			String height, String marks) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.dob = dob;
		this.bloodGroup = bloodGroup;
		this.height = height;
		this.marks = marks;
	}

	public Student(String sid, String sname, String dob, String bloodGroup,
			String height) {
		super();
		this.sid = sid;
		this.sname = sname;
		this.dob = dob;
		this.bloodGroup = bloodGroup;
		this.height = height;
	}

	public void display() {
		System.out.println("the empid is" + sid);
		System.out.println("the empname is" + sname);
		System.out.println("the dob is" + dob);
		System.out.println("the blood group is" + bloodGroup);
		System.out.println("the height is" + height);
		System.out.println("the dob is" + marks);

	}

}
