package com.virtusa.threadsmain.client;

public class Thread2 extends Thread {
	public void run() {
		for (int i = 10; i > 0; i--) {
			System.out.println("The Second thread value is" + i);
		}
	}
}
