package com.virtusa.threadsmain.client;

public class ThreadsMain extends Thread {

	public void run() {
		int i = 0;
		for (i = 0; i < 10; i++) {
			System.out.println("The thread method value is" + i);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadsMain tm = new ThreadsMain();
		tm.start();
		Thread2 t2 = new Thread2();
		t2.start();

	}

}
