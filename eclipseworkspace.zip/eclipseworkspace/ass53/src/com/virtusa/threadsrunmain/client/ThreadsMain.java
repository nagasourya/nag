package com.virtusa.threadsrunmain.client;

public class ThreadsMain implements Runnable {

	public void run() {
		int i = 0;
		for (i = 0; i < 10; i++) {
			System.out.println("The thread method one value is" + i);
		}

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadsMain tm = new ThreadsMain();
		Thread t1 = new Thread(tm);
		t1.start();
		Thread2 t22 = new Thread2();
		Thread t2 = new Thread(t22);
		t2.start();

	}

}
